﻿namespace iData.Feature.CoveoSearch
{
    public static class Constants
    {
        public const string MediaItemCountryCodeFieldName = "CountryCode";
        public const string MediaItemFormatFieldName = "Format";

        public const string DocumentFormatRootFolderId = "{D164F94E-45C4-4C6A-ACE3-7C13051910EA}";

        public const string WebLinkDocumentFormatId = "{EE69A53A-4363-454C-9A83-70D916DF7A2E}";
        


    public static class CustomDateRanges
        {
            public const string TemplateIdString = "{2F39EE42-07A6-45C0-B633-C8BD363E457E}";
            public const string EmptyValueLabel = "Automatic date ranges definition";
        }
    }
}