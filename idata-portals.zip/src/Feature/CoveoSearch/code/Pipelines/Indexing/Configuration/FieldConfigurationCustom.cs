﻿using System;
using Coveo.Framework.Fields.Config;
using Coveo.Framework.Log;
using System.ComponentModel;
using System.Reflection;

namespace iData.Feature.CoveoSearch.Pipelines.Indexing.Configuration
{
    public class FieldConfigurationCustom : Coveo.Framework.Configuration.FieldConfiguration
    {
        public FieldConfigurationCustom() : base()
        {
            
        }

        public FieldConfigurationCustom(string name, string fieldTypeName, string sitecoreFieldName, Type inputType, Type returnType, TypeConverter typeConverter, string sitecoreFormat, FieldConfigParameters fieldConfigParameters) 
            : base(name, fieldTypeName, inputType, returnType, typeConverter, sitecoreFormat, fieldConfigParameters)
        {
            this.SitecoreFieldName = sitecoreFieldName;
        }

        public FieldConfigurationCustom(string name, string fieldTypeName, string sitecoreFieldName, Type inputType, Type returnType, TypeConverter typeConverter, string sitecoreFormat, bool isFacet = false, bool isSortable = false, bool isMultiValue = false, bool isFreeText = false, bool isExternal = false, bool isDisplayField = true, bool isUseForRankingDefined = false, bool useForRanking = false, bool stemming = false, bool useCacheForComputedFacet = false, bool useCacheForNestedQuery = false, bool useCacheForNumericQuery = false, bool useCacheForSort = false) 
            : base(name, fieldTypeName, inputType, returnType, typeConverter, sitecoreFormat, isFacet = false, isSortable = false, isMultiValue = false, isFreeText = false, isExternal = false, isDisplayField = true, isUseForRankingDefined = false, useForRanking = false, stemming = false, useCacheForComputedFacet = false, useCacheForNestedQuery = false, useCacheForNumericQuery = false, useCacheForSort = false)
        {
            this.SitecoreFieldName = sitecoreFieldName;
        }

        public string SitecoreFieldName { get; set; }
    }
}