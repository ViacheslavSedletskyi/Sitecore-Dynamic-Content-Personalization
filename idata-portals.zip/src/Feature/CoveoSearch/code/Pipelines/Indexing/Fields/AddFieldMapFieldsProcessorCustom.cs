﻿using System.Collections.Generic;
using System.Linq;
using Coveo.AbstractLayer.FieldManagement;
using Coveo.AbstractLayer.Pipeline;
using Coveo.Framework.Log;
using Coveo.Framework.Processor;
using System.Reflection;
using iData.Feature.CoveoSearch.Pipelines.Indexing.Helpers;
using iData.Feature.CoveoSearch.Pipelines.Indexing.FieldMap;

namespace iData.Feature.CoveoSearch.Pipelines.Indexing.Fields
{
    public class AddFieldMapFieldsProcessorCustom : IProcessor<CoveoIndexingGetFieldsArgs>
    {
        private readonly static ILogger s_Logger;

        private readonly IFieldFetcherFactory m_FieldFetcherFactory;

        static AddFieldMapFieldsProcessorCustom()
        {
            AddFieldMapFieldsProcessorCustom.s_Logger = CoveoLogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        }

        public AddFieldMapFieldsProcessorCustom() : this(new FieldFetcherFactory())
        {
        }

        public AddFieldMapFieldsProcessorCustom(IFieldFetcherFactory p_FieldFetcherFactory)
        {
            this.m_FieldFetcherFactory = p_FieldFetcherFactory;
        }

        private void AppendFieldMapFields(IList<FieldInformation> p_EffectiveFields, IEnumerable<FieldInformation> p_FieldMapFields)
        {
            if (p_FieldMapFields.Any<FieldInformation>())
            {
                HashSet<string> strs = new HashSet<string>(
                    from field in p_EffectiveFields
                    select field.OriginalFieldName);
                foreach (FieldInformation pFieldMapField in p_FieldMapFields.Where(x => x != null))
                {
                    if (strs.Contains(pFieldMapField.OriginalFieldName))
                    {
                        continue;
                    }
                    p_EffectiveFields.Add(pFieldMapField);
                }
            }
        }

        public void Process(CoveoIndexingGetFieldsArgs args)
        {
            AddFieldMapFieldsProcessorCustom.s_Logger.TraceEntering("Process");
            IEnumerable<FieldInformation> fieldInformations = 
                FieldFetcherFactoryCustom.CreateFieldMapFieldFetcher((ICoveoFieldMapCustom)args.IndexConfiguration.FieldMap).ListFieldInformation();
            this.AppendFieldMapFields(args.Fields, fieldInformations);
            AddFieldMapFieldsProcessorCustom.s_Logger.TraceExiting("Process");
        }
    }
}