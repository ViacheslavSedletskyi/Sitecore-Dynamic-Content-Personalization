﻿using Coveo.Framework.Conversion;
using Coveo.Framework.Log;
using Coveo.Framework.Pipelines;
using Coveo.Framework.Processor;
using Sitecore.ContentSearch;
using System.Reflection;
using iData.Feature.CoveoSearch.Pipelines.Indexing.FieldMap;
using iData.Feature.CoveoSearch.Pipelines.Indexing.Configuration;

namespace iData.Feature.CoveoSearch.Pipelines.Indexing.CoveoFieldConverters
{
    public class FieldValueConverterProcessorCustom : IProcessor<CoveoFieldConverterPipelineArgs>
    {
        private readonly static ILogger s_Logger;

        static FieldValueConverterProcessorCustom()
        {
            s_Logger = CoveoLogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        }

        public FieldValueConverterProcessorCustom()
        {
        }

        private void ConvertUsingFieldConfiguration(CoveoFieldConverterPipelineArgs p_Args, FieldConfigurationCustom p_FieldConfig)
        {
            s_Logger.TraceEntering("ConvertUsingFieldConfiguration");
            s_Logger.Debug("Converts using the TypeConverter and ReturnType from FieldConfiguration");

            p_Args.FieldValue = p_FieldConfig.TypeConverter.ConvertTo(p_Args.FieldValue, p_FieldConfig.ReturnType);

            s_Logger.TraceExiting("ConvertUsingFieldConfiguration");
        }

        private void ConvertValue(CoveoFieldConverterPipelineArgs p_Args, FieldConfigurationCustom p_FieldConfig, ICoveoIndexFieldStorageValueFormatter p_Formatter)
        {
            s_Logger.TraceEntering("ConvertValue");
            if (p_FieldConfig != null && p_FieldConfig.IsReturnTypeValid())
            {
                this.ConvertUsingFieldConfiguration(p_Args, p_FieldConfig);
            }
            else if (p_Formatter == null)
            {
                string str = string.Format("No possible way found to convert field value type : ({0})", p_Args.FieldValue.GetType().FullName);
                s_Logger.Error(str);
            }
            else
            {
                s_Logger.Debug("Trying to convert using the formatter : {0}", p_Formatter);
                p_Args.FieldValue = p_Formatter.FormatValueForIndexStorage(p_Args.FieldValue);
            }
            s_Logger.TraceExiting("ConvertValue");
        }

        public void Process(CoveoFieldConverterPipelineArgs p_Args)
        {
            s_Logger.TraceEntering("FieldValueConverterProcessor");

            var fieldConfiguration = this.RetrieveFieldConfiguration(p_Args.FieldMap, p_Args.FieldName);
            this.ConvertValue(p_Args, fieldConfiguration, p_Args.IndexFieldStorageValueFormatter);

            s_Logger.TraceExiting("FieldValueConverterProcessor");
        }

        private FieldConfigurationCustom RetrieveFieldConfiguration(IFieldMap p_FieldMap, string p_FieldName)
        {
            s_Logger.TraceEntering("RetrieveFieldConfiguration");

            var pFieldMap = p_FieldMap as ICoveoFieldMapCustom;
            FieldConfigurationCustom coveoFieldConfiguration = null;
            if (pFieldMap != null)
            {
                coveoFieldConfiguration = pFieldMap.GetCoveoFieldConfiguration(p_FieldName) as FieldConfigurationCustom;
            }
            s_Logger.TraceExiting("RetrieveFieldConfiguration");

            return coveoFieldConfiguration;
        }
    }
}