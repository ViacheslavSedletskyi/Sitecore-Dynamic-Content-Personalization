﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using Coveo.AbstractLayer.FieldManagement;
using iData.Feature.CoveoSearch.Pipelines.Indexing.FieldMap;

namespace iData.Feature.CoveoSearch.Pipelines.Indexing.Helpers
{
    public class FieldMapFetcherCustom : Coveo.AbstractLayer.FieldManagement.FieldMapFetcher
    {
        private readonly ICoveoFieldMapCustom coveoFieldMap;

        public FieldMapFetcherCustom(ICoveoFieldMapCustom coveoFieldMap) : base(coveoFieldMap)
        {
            this.coveoFieldMap = coveoFieldMap;
        }

        public new IEnumerable<FieldInformation> ListFieldInformation()
        {
            var configs = this.coveoFieldMap.GetAllFieldsConfiguration().ToList();
            
            var fieldInfoList = new List<FieldInformation>();

            fieldInfoList = configs
                .Select(c =>
                    (!string.IsNullOrWhiteSpace(c?.SitecoreFieldName)
                        && !c.SitecoreFieldName.Equals(c.FieldName))
                        ? 
                            new FieldInformation(c.SitecoreFieldName, c.InputType.ToString())
                            { 
                                TranslatedFieldName = c.FieldName,
                            }
                        :   
                            new FieldInformation(c.FieldName, c.InputType.ToString())
                    )
                .ToList();

            return fieldInfoList;
        }
    }
}