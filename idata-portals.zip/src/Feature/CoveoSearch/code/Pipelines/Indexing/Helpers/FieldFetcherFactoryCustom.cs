﻿using iData.Feature.CoveoSearch.Pipelines.Indexing.FieldMap;

namespace iData.Feature.CoveoSearch.Pipelines.Indexing.Helpers
{
    public static class FieldFetcherFactoryCustom
    {
        static FieldFetcherFactoryCustom()
        {
            
        }

        public static FieldMapFetcherCustom CreateFieldMapFieldFetcher(ICoveoFieldMapCustom FieldMap)
        {
            return new FieldMapFetcherCustom(FieldMap);
        }
    }
}