﻿using System;
using System.Collections.Generic;
using Coveo.Framework;
using Coveo.Framework.Utils;
using Sitecore.ContentSearch;
using System.Xml;
using Coveo.SearchProvider;
using iData.Feature.CoveoSearch.Pipelines.Indexing.Configuration;
using Coveo.Framework.Configuration;

namespace iData.Feature.CoveoSearch.Pipelines.Indexing.FieldMap
{
    public class CoveoFieldMapCustom : Coveo.SearchProvider.CoveoFieldMap, IFieldMap, IFieldMapReaders, ICoveoFieldMapCustom
    {
        private readonly ICoveoFieldMapCustom coveoFieldMap;
        private readonly CoveoFieldMapUtils fieldMapUtils;

        public CoveoFieldMapCustom() : this(new CoveoFieldMapBaseCustom())
        {
        }

        public CoveoFieldMapCustom(ICoveoReflectionFactory p_ReflectionFactory) : this(new CoveoFieldMapBaseCustom(new CoveoSettings(new SettingsWrapper()), p_ReflectionFactory))
        {
        }

        public CoveoFieldMapCustom(ICoveoFieldMapCustom fieldMapBase)
        {
            this.coveoFieldMap = fieldMapBase;
            this.fieldMapUtils = new CoveoFieldMapUtils();
        }

        public new void AddFieldByFieldName(string fieldName, Type settingType, IDictionary<string, string> attributes, XmlNode configNode)
        {
            this.coveoFieldMap.AddFieldByFieldName(fieldName, settingType, attributes, configNode);
        }

        public new void AddFieldByFieldName(XmlNode configNode)
        {
            this.coveoFieldMap.AddFieldByFieldName(configNode);
        }

        public new IEnumerable<FieldConfigurationCustom> GetAllFieldsConfiguration()
        {
            return this.coveoFieldMap.GetAllFieldsConfiguration();
        }

        public new AbstractSearchFieldConfiguration GetFieldConfiguration(IIndexableDataField p_Field, Func<AbstractSearchFieldConfiguration, bool> p_FieldVisitorFunc)
        {
            AbstractSearchFieldConfiguration abstractSearchFieldConfiguration;

            if ((this.ValidateFieldConfiguration(this.GetFieldConfigurationByName(p_Field), p_FieldVisitorFunc, out abstractSearchFieldConfiguration) || this.ValidateFieldConfiguration(this.GetFieldConfigurationByTypeKey(p_Field), p_FieldVisitorFunc, out abstractSearchFieldConfiguration) ? false : !this.ValidateFieldConfiguration(this.GetFieldConfigurationByType(p_Field), p_FieldVisitorFunc, out abstractSearchFieldConfiguration)))
            {
                return null;
            }
            return abstractSearchFieldConfiguration;
        }

        private AbstractSearchFieldConfiguration GetFieldConfigurationByName(IIndexableDataField p_Field)
        {
            AbstractSearchFieldConfiguration fieldConfiguration = null;
            if (!string.IsNullOrEmpty(p_Field.Name))
            {
                fieldConfiguration = this.GetFieldConfiguration(p_Field);
            }
            return fieldConfiguration;
        }

        private AbstractSearchFieldConfiguration GetFieldConfigurationByType(IIndexableDataField p_Field)
        {
            AbstractSearchFieldConfiguration fieldConfiguration = null;
            if (p_Field.FieldType != null)
            {
                fieldConfiguration = this.GetFieldConfiguration(p_Field.FieldType);
            }
            return fieldConfiguration;
        }

        private bool ValidateFieldConfiguration(AbstractSearchFieldConfiguration fieldConfiguration, Func<AbstractSearchFieldConfiguration, bool> p_FieldVisitorFunc, out AbstractSearchFieldConfiguration p_ReturnedFieldConfiguration)
        {
            if (fieldConfiguration != null && p_FieldVisitorFunc(fieldConfiguration))
            {
                p_ReturnedFieldConfiguration = fieldConfiguration;
                return true;
            }
            p_ReturnedFieldConfiguration = null;
            return false;
        }

        private AbstractSearchFieldConfiguration GetFieldConfigurationByTypeKey(IIndexableDataField p_Field)
        {
            AbstractSearchFieldConfiguration fieldConfiguration = null;
            if (!string.IsNullOrEmpty(p_Field.TypeKey))
            {
                Type type = Type.GetType(p_Field.TypeKey, false, true);
                if (type != null)
                {
                    fieldConfiguration = this.GetFieldConfiguration(type);
                }
            }
            return fieldConfiguration;
        }
        
        public new FieldConfiguration GetCoveoFieldConfiguration(string p_FieldName)
        {
            return this.coveoFieldMap.GetCoveoFieldConfiguration(p_FieldName) as FieldConfiguration;
        }
    }
}