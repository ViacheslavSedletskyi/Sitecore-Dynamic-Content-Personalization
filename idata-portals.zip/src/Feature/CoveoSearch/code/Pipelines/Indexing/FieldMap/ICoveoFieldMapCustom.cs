﻿using Coveo.Framework.Configuration;
using iData.Feature.CoveoSearch.Pipelines.Indexing.Configuration;
using System.Collections.Generic;

namespace iData.Feature.CoveoSearch.Pipelines.Indexing.FieldMap
{
    public interface ICoveoFieldMapCustom : Coveo.Framework.Fields.ICoveoFieldMap
    {
        new IEnumerable<FieldConfigurationCustom> GetAllFieldsConfiguration();
        
        new FieldConfiguration GetCoveoFieldConfiguration(string p_FieldName);
    }
}
