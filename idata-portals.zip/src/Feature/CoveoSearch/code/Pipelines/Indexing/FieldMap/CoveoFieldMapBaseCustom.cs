﻿using Coveo.Framework.Utils;
using iData.Feature.CoveoSearch.Pipelines.Indexing.Configuration;
using Sitecore.Xml;
using System;
using System.Collections.Generic;
using System.Xml;
using Coveo.Framework;
using Coveo.Framework.Exceptions;
using Coveo.Framework.Fields.Config;
using Coveo.Framework.Log;
using System.ComponentModel;
using System.Reflection;
using Coveo.Framework.Configuration;

namespace iData.Feature.CoveoSearch.Pipelines.Indexing.FieldMap
{
    public class CoveoFieldMapBaseCustom : Coveo.Framework.Fields.CoveoFieldMapBase, ICoveoFieldMapCustom
    {
        private readonly static ILogger Logger;
        private readonly Dictionary<string, FieldConfigurationCustom> fieldNameMap = new Dictionary<string, FieldConfigurationCustom>();
        private readonly ICoveoSettings settings;

        static CoveoFieldMapBaseCustom()
        {
            Logger = CoveoLogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        }

        public CoveoFieldMapBaseCustom() : base() { }

        public CoveoFieldMapBaseCustom(ICoveoReflectionFactory coveoReflectionFactory) : base(coveoReflectionFactory) { }

        internal CoveoFieldMapBaseCustom(ICoveoSettings coveoSettings, ICoveoReflectionFactory coveoReflectionFactory)
        {
            this.settings = coveoSettings;
            this.CoveoReflectionFactory = coveoReflectionFactory;
        }

        public new void AddFieldByFieldName(XmlNode configNode)
        {
            Logger.TraceEntering("AddFieldByFieldName");

            FieldConfigurationCustom fieldConfiguration = this.CreateFieldConfiguration(configNode);

            var fielName = fieldConfiguration.FieldName.ToLowerInvariant();

            if (!String.IsNullOrWhiteSpace(fieldConfiguration?.SitecoreFieldName) && !fieldConfiguration.SitecoreFieldName.ToLowerInvariant().Equals(fieldConfiguration.FieldName.ToLowerInvariant()))
            {
                fielName = fieldConfiguration.SitecoreFieldName.ToLowerInvariant();
            }

            this.fieldNameMap[fielName] = fieldConfiguration;

            Logger.TraceExiting("AddFieldByFieldName");
        }

        public new void AddFieldByFieldName(string p_FieldName, Type p_FieldType, IDictionary<string, string> p_Attributes, XmlNode configNode)
        {
            Logger.TraceEntering("AddFieldByFieldName");
            var fieldConfiguration = this.CreateFieldConfiguration(p_FieldName, null, configNode);

            var fielName = fieldConfiguration.FieldName.ToLowerInvariant();

            if (!String.IsNullOrWhiteSpace(fieldConfiguration?.SitecoreFieldName) && !fieldConfiguration.SitecoreFieldName.ToLowerInvariant().Equals(fieldConfiguration.FieldName.ToLowerInvariant()))
            {
                fielName = fieldConfiguration.SitecoreFieldName.ToLowerInvariant();
            }

            this.fieldNameMap[fielName] = fieldConfiguration;

            Logger.TraceExiting("AddFieldByFieldName");
        }

        private FieldConfigurationCustom CreateFieldConfiguration(XmlNode configNode)
        {
            return this.CreateFieldConfiguration(null, null, configNode);
        }

        private FieldConfigurationCustom CreateFieldConfiguration(string fieldNameValue, string fieldTypeNameValue, XmlNode configNode)
        {
            Logger.TraceEntering("CreateFieldConfiguration");
            FieldConfigurationCustom fieldConfiguration = null;
            if (configNode != null)
            {
                string pFieldNameValue = fieldNameValue ?? XmlUtil.GetAttribute("fieldName", configNode);
                string pFieldTypeNameValue = fieldTypeNameValue ?? XmlUtil.GetAttribute("fieldTypeName", configNode);
                string pSitecoreFieldNameValue = /*fieldTypeNameValue ??*/ XmlUtil.GetAttribute("sitecoreFieldName", configNode);
                string attribute = XmlUtil.GetAttribute("settingType", configNode);
                string str = XmlUtil.GetAttribute("type", configNode);
                string attribute1 = XmlUtil.GetAttribute("returnType", configNode);
                string str1 = XmlUtil.GetAttribute("typeConverter", configNode);
                string attribute2 = XmlUtil.GetAttribute("isFacet", configNode, "false");
                string str2 = XmlUtil.GetAttribute("isSortable", configNode, "false");
                string attribute3 = XmlUtil.GetAttribute("isMultiValue", configNode, "false");
                string str3 = XmlUtil.GetAttribute("includeForFreeTextSearch", configNode, "false");
                string attribute4 = XmlUtil.GetAttribute("isDisplayField", configNode, "true");
                string str4 = XmlUtil.GetAttribute("isExternal", configNode);
                string attribute5 = XmlUtil.GetAttribute("sitecoreFormat", configNode);
                string str5 = XmlUtil.GetAttribute("useForRanking", configNode);
                string attribute6 = XmlUtil.GetAttribute("useStemming", configNode, "false");
                string str6 = XmlUtil.GetAttribute("useCacheForComputedFacet", configNode, "false");
                string attribute7 = XmlUtil.GetAttribute("useCacheForNestedQuery", configNode, "false");
                string str7 = XmlUtil.GetAttribute("useCacheForNumericQuery", configNode, "false");
                string attribute8 = XmlUtil.GetAttribute("useCacheForSort", configNode, "false");
                string str8 = XmlUtil.GetAttribute("isSourceSpecific", configNode);
                if (string.IsNullOrEmpty(pFieldNameValue) || string.IsNullOrEmpty(attribute))
                {
                    string str9 = "Unable to process 'AddFieldByFieldName' config section.";
                    Logger.Error(str9);
                    throw new FieldMapException(str9);
                }
                fieldConfiguration = this.CreateConfig(pFieldNameValue, pFieldTypeNameValue, pSitecoreFieldNameValue, str, attribute1, str1, attribute, attribute2, str2, attribute3, str3, attribute4, str4, attribute5, str5, attribute6, str6, attribute7, str7, attribute8, str8, configNode.ChildNodes);
            }
            Logger.TraceExiting("CreateFieldConfiguration");

            return fieldConfiguration;
        }

        private FieldConfigurationCustom CreateConfig(string p_Name, string p_FieldTypeName, string pSitecoreFieldNameValue, string p_InputTypeName, string p_ReturnTypeName, string p_TypeconverterName, string p_SettingTypeInfoName, string p_IsFacet, string p_IsSortable, string p_IsMultiValue, string p_IsFreeText, string p_IsDisplayField, string p_IsExternal, string p_Format, string p_UseForRanking, string p_Stemming, string p_UseCacheForComputedFacet, string p_UseCacheForNestedQuery, string p_UseCacheForNumericQuery, string p_UseCacheForSort, string p_IsSourceSpecific, XmlNodeList p_ConfigNodeList)
        {
            Logger.TraceEntering("CreateConfig");
            Type typeInfo = this.CoveoReflectionFactory.GetTypeInfo(p_InputTypeName);
            Type type = this.CoveoReflectionFactory.GetTypeInfo(p_ReturnTypeName);
            object[] objArray = this.CoveoReflectionFactory.CreateListOfInstanceFromXmlNodeList(p_ConfigNodeList, "param", "type");
            TypeConverter typeConverter = this.CoveoReflectionFactory.CreateInstanceGeneric<TypeConverter>(p_TypeconverterName, objArray);
            FieldConfigParameters fieldConfigParameters = this.GetFieldConfigParameters(p_IsFacet, p_IsSortable, p_IsMultiValue, p_IsFreeText, p_IsDisplayField, p_IsExternal, p_UseForRanking, p_Stemming, p_UseCacheForComputedFacet, p_UseCacheForNestedQuery, p_UseCacheForNumericQuery, p_UseCacheForSort, p_IsSourceSpecific);
            object[] pName = new object[] { p_Name, p_FieldTypeName, pSitecoreFieldNameValue, typeInfo, type, typeConverter, p_Format, fieldConfigParameters };
            FieldConfigurationCustom fieldConfiguration = null;
            if (p_SettingTypeInfoName != null)
            {
                try
                {
                    Logger.Debug("Create instance of {0} ", p_SettingTypeInfoName);
                    fieldConfiguration = this.CoveoReflectionFactory.CreateInstanceGeneric<FieldConfigurationCustom>(p_SettingTypeInfoName, pName);
                }
                catch (Exception exception1)
                {
                    Exception exception = exception1;
                    string str = string.Format("Unable to create instance of: {0}", p_SettingTypeInfoName);
                    Logger.Error(str, exception);
                    throw new FieldMapException(str, exception);
                }
            }

            if (fieldConfiguration == null)
            {
                string str1 = string.Format("Unable to create: {0}", p_SettingTypeInfoName);
                Logger.Error(str1);
                throw new FieldMapException(str1);
            }

            Logger.TraceExiting("CreateConfig");
            return fieldConfiguration;
        }

        private FieldConfigParameters GetFieldConfigParameters(string p_IsFacet, string p_IsSortable, string p_IsMultiValue, string p_IsFreeText, string p_IsDisplayField, string p_IsExternal, string p_UseForRanking, string p_Stemming, string p_UseCacheForComputedFacet, string p_UseCacheForNestedQuery, string p_UseCacheForNumericQuery, string p_UseCacheForSort, string p_IsSourceSpecific)
        {
            bool flag;
            bool flag1;
            bool flag2;
            FieldConfigParameters fieldConfigParameters = (FieldConfigParameters)0;
            fieldConfigParameters = this.AddParameterToFieldConfigParameters(fieldConfigParameters, FieldConfigParameters.IsFacet, p_IsFacet);
            fieldConfigParameters = this.AddParameterToFieldConfigParameters(fieldConfigParameters, FieldConfigParameters.IsSortable, p_IsSortable);
            fieldConfigParameters = this.AddParameterToFieldConfigParameters(fieldConfigParameters, FieldConfigParameters.IsMultiValue, p_IsMultiValue);
            fieldConfigParameters = this.AddParameterToFieldConfigParameters(fieldConfigParameters, FieldConfigParameters.IsIncludedFreeText, p_IsFreeText);
            fieldConfigParameters = this.AddParameterToFieldConfigParameters(fieldConfigParameters, FieldConfigParameters.IsDisplayField, p_IsDisplayField);
            fieldConfigParameters = this.AddParameterToFieldConfigParameters(fieldConfigParameters, FieldConfigParameters.UseStemming, p_Stemming);
            fieldConfigParameters = this.AddParameterToFieldConfigParameters(fieldConfigParameters, FieldConfigParameters.UseCacheForComputedFacet, p_UseCacheForComputedFacet);
            fieldConfigParameters = this.AddParameterToFieldConfigParameters(fieldConfigParameters, FieldConfigParameters.UseCacheForNestedQuery, p_UseCacheForNestedQuery);
            fieldConfigParameters = this.AddParameterToFieldConfigParameters(fieldConfigParameters, FieldConfigParameters.UseCacheForNumericQuery, p_UseCacheForNumericQuery);
            fieldConfigParameters = this.AddParameterToFieldConfigParameters(fieldConfigParameters, FieldConfigParameters.UseCacheForSort, p_UseCacheForSort);
            if (bool.TryParse(p_UseForRanking, out flag))
            {
                fieldConfigParameters |= FieldConfigParameters.IsUseForRankingDefined;
                if (flag)
                {
                    fieldConfigParameters |= FieldConfigParameters.UseForRanking;
                }
            }
            bool flag3 = bool.TryParse(p_IsExternal, out flag1);
            if (bool.TryParse(p_IsSourceSpecific, out flag2))
            {
                fieldConfigParameters |= FieldConfigParameters.IsSourceSpecificDefined;
                if (flag2)
                {
                    fieldConfigParameters |= FieldConfigParameters.IsSourceSpecific;
                }
            }
            else if (flag3)
            {
                fieldConfigParameters |= FieldConfigParameters.IsSourceSpecificDefined;
                if (!flag1)
                {
                    fieldConfigParameters |= FieldConfigParameters.IsSourceSpecific;
                }
            }
            return fieldConfigParameters;
        }

        private FieldConfigParameters AddParameterToFieldConfigParameters(FieldConfigParameters p_FieldConfigParameters, FieldConfigParameters p_ParameterToAdd, string p_ParameterValue)
        {
            FieldConfigParameters pFieldConfigParameters = p_FieldConfigParameters;
            if (this.TryGetBooleanValue(p_ParameterValue))
            {
                pFieldConfigParameters |= p_ParameterToAdd;
            }
            return pFieldConfigParameters;
        }

        private bool TryGetBooleanValue(string p_Value)
        {
            bool flag;
            bool.TryParse(p_Value, out flag);
            return flag;
        }

        public new IEnumerable<FieldConfigurationCustom> GetAllFieldsConfiguration()
        {
            return this.fieldNameMap.Values;
        }
        
        public new FieldConfiguration GetCoveoFieldConfiguration(string p_FieldName)
        {
            FieldConfigurationCustom fieldConfiguration;

            if (!this.fieldNameMap.TryGetValue(p_FieldName.ToLowerInvariant(), out fieldConfiguration))
            {
                Logger.Error($"Field: {p_FieldName} configuration doesn't exists");
            }

            return fieldConfiguration as FieldConfiguration;
        }
    }
}