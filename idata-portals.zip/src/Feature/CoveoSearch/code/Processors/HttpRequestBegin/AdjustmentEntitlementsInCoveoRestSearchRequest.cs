﻿using Coveo.Framework.Configuration;
using Coveo.Framework.Pipelines;
using Coveo.Framework.Utils;
using iData.Feature.CoveoSearch.HttpModule;
using Sitecore.Pipelines.HttpRequest;
using System.IO;
using System.Linq;

namespace iData.Feature.CoveoSearch.Processors.HttpRequestBegin
{
    public class AdjustmentEntitlementsInCoveoRestSearchRequest : HttpRequestProcessor
    {
        private readonly RestEndpointConfiguration m_Configuration;

        public AdjustmentEntitlementsInCoveoRestSearchRequest() : this((new RestEndpointConfigurationFactory()).GetConfiguration())
        {
        }

        public AdjustmentEntitlementsInCoveoRestSearchRequest(RestEndpointConfiguration configuration)
        {
            m_Configuration = configuration;
        }


        private bool IsRestSearchEndpointRequest(string p_RequestFilePath)
        {
            string restEndpointPath = !string.IsNullOrEmpty(m_Configuration.RestEndpointPath) ? m_Configuration.RestEndpointPath.Trim().TrimEnd(new char[] { '/' }) : "";
            string requestFilePath = !string.IsNullOrEmpty(p_RequestFilePath) ? p_RequestFilePath.Trim().TrimEnd(new char[] { '/' }) : "";
            
            return StringUtilities.EqualsIgnoreCase(requestFilePath, restEndpointPath) ? true : StringUtilities.StartsWithIgnoreCase(requestFilePath, string.Concat(restEndpointPath, "/"));
        }

        public override void Process(HttpRequestArgs args)
        {
            var request = args.HttpContext.Request;

            IHttpRequestArgs coveoRequestArgs = HttpRequestArgsProvider.GetInstance(args);
            if (!string.IsNullOrEmpty(m_Configuration.RestEndpointPath) && IsRestSearchEndpointRequest(coveoRequestArgs.RequestFilePath))
            {
                //Coveo Search API request
                if (args.HttpContext.Request.Form.AllKeys.FirstOrDefault(key =>
                    key.ToLower().StartsWith("aq")) != null)
                {
                    args.HttpContext.Request.Filter =
                        new FormRewriteFilter(
                            args.HttpContext.Request.Filter,
                            args.HttpContext.Request.ContentEncoding,
                            new FormRewriter());
                }
            }
            else
            {
                //Another request
            }
        }
    }
}