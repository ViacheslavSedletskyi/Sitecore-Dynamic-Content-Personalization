﻿using Coveo.Framework.CNL;
using Coveo.Framework.Databases;
using Coveo.Framework.Items;
using Coveo.Framework.Log;
using Coveo.Framework.Pipelines;
using Coveo.Framework.Processor;
using Coveo.Framework.Utils;
using Coveo.SearchProvider.ContentSearch;
using Coveo.SearchProvider.Rest.Pipelines;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Sitecore.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;
using iData.Foundation.Security.Services;
using PlatformConstants = iData.Foundation.Platform.Constants;
using PlatformTemplates = iData.Foundation.Platform.Templates;
using iData.Foundation.Sitecore.Extensions;
using Coveo.Framework.Collections;
using iData.Feature.CoveoSearch.ComputedFields;
using Newtonsoft.Json;

namespace iData.Feature.CoveoSearch.Processors.CoveoProcessParsedRestResponse
{
	public class AdjustEntitlementRestrictionsProcessor : IProcessor<CoveoProcessParsedRestResponseArgs>
	{
		private static readonly ILogger s_Logger = CoveoLogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

		public AdjustEntitlementRestrictionsProcessor() : this(new UrlUtilities(), new CoveoIndexFetcher(), new DatabaseFactory(), new ItemUriFactory(), new PipelineRunnerHandler(new PipelineRunner()), new SitecoreFactoryWrapper())
		{
		}

		internal AdjustEntitlementRestrictionsProcessor(IUrlUtilities p_UrlUtilities, ICoveoIndexFetcher p_CoveoIndexFetcher, IDatabaseFactory p_DatabaseFactory, IItemUriFactory p_ItemUriFactory, IPipelineRunnerHandler p_PipelineRunnerHandler, ISitecoreFactory p_SitecoreFactory)
		{
			s_Logger.TraceEntering("AdjustEntitlementRestrictionsProcessor");

			Precondition.NotNull(p_UrlUtilities, () => () => p_UrlUtilities);
			Precondition.NotNull(p_CoveoIndexFetcher, () => () => p_CoveoIndexFetcher);
			Precondition.NotNull(p_DatabaseFactory, () => () => p_DatabaseFactory);
			Precondition.NotNull(p_ItemUriFactory, () => () => p_ItemUriFactory);
			Precondition.NotNull(p_PipelineRunnerHandler, () => () => p_PipelineRunnerHandler);
			Precondition.NotNull(p_SitecoreFactory, () => () => p_SitecoreFactory);

			s_Logger.TraceExiting("AdjustEntitlementRestrictionsProcessor");
		}

		public void Process(CoveoProcessParsedRestResponseArgs p_Args)
		{
			s_Logger.TraceEntering("Process");
			Precondition.NotNull(p_Args, () => () => p_Args);

			var externalAuthorizationService = ServiceLocator.ServiceProvider.GetRequiredService<IExternalAuthorizationService>();
			var authorizedDatasets = externalAuthorizationService.GetAuthorizedDatasets(global::Sitecore.Context.User);

			if (authorizedDatasets != null && authorizedDatasets.Any())
            {
				foreach (var dataset in authorizedDatasets)
				{
					if (dataset.Metadata != null && dataset.Metadata.Any())
					{
						var metadataCoveoSearchList = new Dictionary<string, List<string>>(dataset.Metadata.Count());

						foreach (var metadata in dataset.Metadata)
						{
							var metadataSearchFieldName = PlatformConstants.PortalMetadataCoveoFieldPrefix + metadata.FieldName;
							var metadataFieldSearchString = "/sitecore/catalog/*[@@templateid='" + PlatformTemplates.MetadataFieldsRootFolder.ID + "']//*[@searchField='" + metadataSearchFieldName + "']";
							var glossaryMetadataFolderItem = global::Sitecore.Context.Database.SelectSingleItem(metadataFieldSearchString)?.TargetItem(PlatformTemplates.MetadataField.Fields.GlossarySourceFolder.ToString());

							var glossaryMetadataItem = glossaryMetadataFolderItem?.Axes.SelectSingleItem($".//*[@@templateid='{ PlatformTemplates.Glossary.ID }' and @Code='{ metadata.Value.ToString() }']");

							if (glossaryMetadataItem != null)
							{
								if (metadataCoveoSearchList.ContainsKey(metadataSearchFieldName))
								{
									metadataCoveoSearchList[metadataSearchFieldName].Add(glossaryMetadataItem[PlatformTemplates.Glossary.Fields.Name]);
								}
								else
								{
									metadataCoveoSearchList.Add(metadataSearchFieldName, new List<string>() { glossaryMetadataItem[PlatformTemplates.Glossary.Fields.Name] });
								}
							}
						}

						if (metadataCoveoSearchList.Any())
						{
							p_Args.ResponseContent.Results.ForEach(resultContent => {
								object datasetUrnObj = null;
								if (resultContent.Raw.TryGetValue("idata_urn", out datasetUrnObj) || resultContent.Raw.TryGetValue("idata_dataset_urn", out datasetUrnObj))
                                {
									var datasetUrn = JsonConvert.SerializeObject(datasetUrnObj);
									if (datasetUrn.Contains(dataset.Urn))
                                    {
										foreach(var allowedMetadata in metadataCoveoSearchList)
                                        {
											if (resultContent.Raw.ContainsKey(allowedMetadata.Key))
											{
												resultContent.Raw[allowedMetadata.Key] = allowedMetadata.Value;
											}

											//Pipeline should be used here
											if (allowedMetadata.Key.ToLower() == PlatformConstants.PortalMetadataCoveoFieldPrefix + "ref_area_name" && resultContent.Raw.ContainsKey("idata_coverage_area"))
                                            {
												//Call re-calculate Coveo index field if nesessary, use pipeline or configuration; use Fields config to get desire computed field processor class
												resultContent.Raw["idata_coverage_area"] = new CoverageAreaComputedField().ComputeFieldValueByEntitlements(allowedMetadata.Key.ToLower(), allowedMetadata.Value.ToArray(), p_Args.CurrentContextItem.Database.SitecoreDatabase);
											}
										}
									}
								}
							});
						}
					}
				}
			}

			s_Logger.TraceExiting("Process");
		}
	}
}