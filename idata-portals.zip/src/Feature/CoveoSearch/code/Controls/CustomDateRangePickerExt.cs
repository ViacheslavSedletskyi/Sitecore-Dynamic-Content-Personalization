﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using Coveo.Framework.CNL;
using Coveo.Framework.Databases;
using Coveo.Framework.Items;
using Coveo.Framework.Log;
using Coveo.Framework.Utils;
using Coveo.UI.Controls.Dependencies;
using Coveo.UI.Controls.Helpers;
using Sitecore;
using Sitecore.Web.UI.HtmlControls;
using Sitecore.Web.UI.Sheer;
using System.Linq.Expressions;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using Coveo.UI.Controls.Controls;
using Coveo.UI.Core.Strings;
using Coveo.UI.Core.Helpers;
using Coveo.UI.Controls.Controls.BaseControls;

namespace iData.Feature.CoveoSearch.Controls
{
    public class CustomDateRangePickerExt : Sitecore.Web.UI.HtmlControls.Control
    {
        private readonly static ILogger Logger;
        private string source;
        private readonly ISitecoreContext SitecoreContext;
        private readonly IControlsUtilities ControlsUtilities;
        private readonly ISitecoreEventsUtilities SitecoreEventsUtilities;
        private readonly ILocalizedStringFetcher Labels;

        protected IDatabaseWrapper CurrentDatabase
        {
            get
            {
                return this.SitecoreContext.GetCurrentDatabase();
            }
        }

        public virtual string ItemID
        {
            get
            {
                return base.GetViewStateString("ItemID");
            }
            set
            {
                base.SetViewStateString("ItemID", value);
            }
        }

        public virtual string ItemLanguage
        {
            get
            {
                return base.GetViewStateString("ItemLanguage");
            }
            set
            {
                base.SetViewStateString("ItemLanguage", value);
            }
        }

        public virtual string Separator
        {
            get
            {
                return base.GetViewStateString("separator", ", ");
            }
            set
            {
                base.SetViewStateString("separator", value);
            }
        }

        public virtual string Source
        {
            get
            {
                return StringUtil.GetString(new string[] { this.source });
            }
            set
            {
                string str;
                this.source = this.ControlsUtilities.BuildSourcePath(value, out str);
                if (str != null)
                {
                    this.Separator = str;
                }
            }
        }

        public virtual bool TrackModified
        {
            get
            {
                return base.GetViewStateBool("TrackModified", true);
            }
            set
            {
                base.SetViewStateBool("TrackModified", value, true);
            }
        }

        public override string Value
        {
            get
            {
                return base.Value;
            }
            set
            {
                if (value != base.Value)
                {
                    this.TrackModified = true;
                }
                base.Value = value;
            }
        }

        protected virtual string CustomRangeTemplateId
        {
            get
            {
                return Constants.CustomDateRanges.TemplateIdString;
            }
        }

        protected virtual string EmptyHeaderCaptionKey
        {
            get
            {
                return Constants.CustomDateRanges.EmptyValueLabel;
            }
        }

        static CustomDateRangePickerExt()
        {
            CustomDateRangePickerExt.Logger = CoveoLogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        }

        public CustomDateRangePickerExt() : base()
        {
            this.Class = "scContentControl";
            base.Activation = true;
            this.Labels = StaticControlsServiceFetcher.GetService<ILocalizedStringFetcher>();
            this.SitecoreContext = StaticControlsServiceFetcher.GetService<ISitecoreContext>();
            this.ControlsUtilities = StaticControlsServiceFetcher.GetService<IControlsUtilities>();
            this.SitecoreEventsUtilities = StaticControlsServiceFetcher.GetService<ISitecoreEventsUtilities>();
        }

        protected virtual IEnumerable<ListItem> ConvertToListItems(IEnumerable<IItem> Items)
        {
            return this.ControlsUtilities.ConvertToListItems(Items);
        }
        
        protected virtual void CreateSubControls()
        {
            CustomDateRangePickerExt.Logger.TraceEntering("CreateSubControls");
            HtmlGenericControl htmlGenericControl = new HtmlGenericControl("div");
            this.Controls.Add(htmlGenericControl);
            HtmlGenericControl htmlGenericControl1 = new HtmlGenericControl("span");
            htmlGenericControl.Controls.Add(htmlGenericControl1);
            htmlGenericControl1.Controls.Add(new Literal(this.Labels["Select Ranges"]));
            DropDownList dropDownList = new DropDownList();
            htmlGenericControl.Controls.Add(dropDownList);
            dropDownList.ID = base.GetID("Ranges");
            dropDownList.Disabled = this.Disabled;
            dropDownList.ItemLanguage = this.ItemLanguage;
            dropDownList.Change = "event:change";
            CustomDateRangePickerExt.Logger.TraceExiting("CreateSubControls");
        }
        
        protected virtual ListItem[] GetCustomRangeItems()
        {
            CustomDateRangePickerExt.Logger.TraceEntering("GetCustomRangeItems");
            IEnumerable<ListItem> listItems = this.ConvertToListItems(this.CurrentDatabase.SelectItems(string.Concat("fast:/Sitecore/Content//*[@@Templateid='", this.CustomRangeTemplateId, "']")));
            CustomDateRangePickerExt.Logger.TraceExiting("GetCustomRangeItems");
            return listItems.ToArray<ListItem>();
        }

        protected virtual DropDownList GetCustomRangesList()
        {
            return this.FindControl(base.GetID("Ranges")) as DropDownList;
        }

        protected virtual string GetEmptyHeaderCaption()
        {
            return this.Labels[this.EmptyHeaderCaptionKey];
        }

        public override void HandleMessage(Message Message)
        {
            CustomDateRangePickerExt.Logger.TraceEntering("HandleMessage");
            if (this.SitecoreEventsUtilities.IsChangeEvent(Message) && this.SitecoreEventsUtilities.GetEventSource(Message) == this.GetCustomRangesList().ID)
            {
                this.HandleRangeChanged();
            }
            base.HandleMessage(Message);
            CustomDateRangePickerExt.Logger.TraceExiting("HandleMessage");
        }
        
        protected virtual void HandleRangeChanged()
        {
            this.Value = this.GetCustomRangesList().Value;
        }

        protected virtual void LoadRangeList()
        {
            ListItem[] customRangeItems = this.GetCustomRangeItems();
            this.GetCustomRangesList().SetItems((
                from item in customRangeItems
                orderby item.Header
                select item).ToArray<ListItem>(), true);
        }

        protected virtual void LoadSubControlsData()
        {
            this.SetSubControlData();
        }

        protected override void OnLoad(EventArgs p_Args)
        {
            CustomDateRangePickerExt.Logger.TraceEntering("OnLoad");
            if (!this.SitecoreContext.ClientPage.IsEvent)
            {
                this.CreateSubControls();
                this.LoadSubControlsData();
            }
            base.OnLoad(p_Args);
            CustomDateRangePickerExt.Logger.TraceExiting("OnLoad");
        }

        protected virtual void SetSubControlData()
        {
            this.GetCustomRangesList().EmptyValueHeader = this.GetEmptyHeaderCaption();
            this.LoadRangeList();
            this.GetCustomRangesList().Value = this.Value;
        }
    }
}