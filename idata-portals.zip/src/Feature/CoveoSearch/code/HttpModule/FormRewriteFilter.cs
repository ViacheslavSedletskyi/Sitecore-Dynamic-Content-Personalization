﻿using System;
using System.IO;
using System.Text;

namespace iData.Feature.CoveoSearch.HttpModule
{
    internal class FormRewriteFilter : Stream
    {
        private readonly Stream _stream;
        private readonly Encoding _encoding;
        private readonly IFormRewriter _rewriter;

        private MemoryStream _buffer;

        public FormRewriteFilter(Stream stream, Encoding encoding, IFormRewriter rewriter)
        {
            _stream = stream;
            _encoding = encoding;
            _rewriter = rewriter;
        }

        public override bool CanRead => true;

        public override bool CanSeek => false;

        public override bool CanWrite => false;

        public override long Length
        {
            get
            {
                EnsureBuffer();
                return _buffer.Length;
            }
        }

        public override long Position
        {
            get
            {
                EnsureBuffer();
                return _buffer.Position;
            }

            set => throw new NotImplementedException();
        }

        public override void Flush()
        {
            EnsureBuffer();
            _buffer.Flush();
        }

        public override int Read(byte[] buffer, int offset, int count)
        {
            EnsureBuffer();
            return _buffer.Read(buffer, offset, count);
        }

        public override long Seek(long offset, SeekOrigin origin)
        {
            EnsureBuffer();
            return _buffer.Seek(offset, origin);
        }

        public override void SetLength(long value)
        {
            EnsureBuffer();
            _buffer.SetLength(value);
        }

        public override void Write(byte[] buffer, int offset, int count)
        {
            throw new NotImplementedException();
        }

        private void EnsureBuffer()
        {
            if (_buffer == null)
            {
                var sr = new StreamReader(_stream, _encoding);
                string inputContent = sr.ReadToEnd();

                var inputForm = FormUtils.ParseQueryString(inputContent);
                var resultForm = _rewriter.Rewrite(inputForm);
                var resultContent = FormUtils.BuildQueryString(resultForm);

                byte[] bytes = _encoding.GetBytes(resultContent);
                _buffer = new MemoryStream();
                _buffer.Write(bytes, 0, bytes.Length);
                _buffer.Seek(0, SeekOrigin.Begin);
            }
        }
    }
}