﻿using Sitecore.DependencyInjection;
using System.Collections.Generic;
using Microsoft.Extensions.DependencyInjection;
using iData.Foundation.Security.Services;
using System.Linq;
using PlatformConstants = iData.Foundation.Platform.Constants;
using PlatformTemplates = iData.Foundation.Platform.Templates;
using iData.Foundation.Sitecore.Extensions;
using Sitecore.Diagnostics;

namespace iData.Feature.CoveoSearch.HttpModule
{
    internal class FormRewriter : IFormRewriter
    {
        public IDictionary<string, string> Rewrite(IDictionary<string, string> form)
        {
            string filter = string.Empty;

            if (form.ContainsKey("aq") && !string.IsNullOrEmpty(form["aq"]))
            {
                var externalAuthorizationService = ServiceLocator.ServiceProvider.GetRequiredService<IExternalAuthorizationService>();
                var authorizedDatasets = externalAuthorizationService.GetAuthorizedDatasets(global::Sitecore.Context.User);

                if (authorizedDatasets != null && authorizedDatasets.Any())
                {
                    var datasetCoveoSearchList = new List<string>(authorizedDatasets.Count());

                    foreach (var dataset in authorizedDatasets)
                    {
                        if (dataset.Metadata != null && dataset.Metadata.Any())
                        {
                            var metadataCoveoSearchList = new Dictionary<string, List<string>>(dataset.Metadata.Count());

                            foreach (var metadata in dataset.Metadata)
                            {
                                var metadataSearchFieldName = PlatformConstants.PortalMetadataCoveoFieldPrefix + metadata.FieldName;
                                var metadataFieldSearchString = "/sitecore/catalog/*[@@templateid='" + PlatformTemplates.MetadataFieldsRootFolder.ID + "']//*[@searchField='" + metadataSearchFieldName + "']";
                                var glossaryMetadataFolderItem = global::Sitecore.Context.Database.SelectSingleItem(metadataFieldSearchString)?.TargetItem(PlatformTemplates.MetadataField.Fields.GlossarySourceFolder.ToString());

                                var glossaryMetadataItem = glossaryMetadataFolderItem?.Axes.SelectSingleItem($".//*[@@templateid='{ PlatformTemplates.Glossary.ID }' and @Code='{ metadata.Value.ToString() }']");

                                if (glossaryMetadataItem != null)
                                {
                                    if (metadataCoveoSearchList.ContainsKey(metadataSearchFieldName))
                                    {
                                        metadataCoveoSearchList[metadataSearchFieldName].Add($"\"{ glossaryMetadataItem[PlatformTemplates.Glossary.Fields.Name] }\"");
                                    }
                                    else
                                    {
                                        metadataCoveoSearchList.Add(metadataSearchFieldName, new List<string>() { $"\"{ glossaryMetadataItem[PlatformTemplates.Glossary.Fields.Name] }\"" });
                                    }
                                }
                            }

                            if (metadataCoveoSearchList.Any())
                            {
                                datasetCoveoSearchList.Add($"((@idata_urn==(\"{ dataset.Urn }\") OR @idata_dataset_urn==(\"{ dataset.Urn }\")) ({ string.Join(" ", metadataCoveoSearchList.Select(metadata => $"@{metadata.Key}==({ string.Join(", ", metadata.Value) })")) }))");
                            }
                        }
                    }

                    var advancedQueryResult = $" ( { string.Join(" OR ", datasetCoveoSearchList) } )";

                    Log.Info($"Resulted advanced query: { advancedQueryResult }", this);

                    filter += advancedQueryResult;
                }

                form["aq"] += filter;
            }

            return form;
        }
    }
}