﻿using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;

namespace iData.Feature.CoveoSearch.HttpModule
{
    internal static class FormUtils
    {
        public static IDictionary<string, string> ParseQueryString(string queryString)
        {
            if (string.IsNullOrWhiteSpace(queryString))
            {
                return new Dictionary<string, string>();
            }

            return queryString.Split('&').Select(v => v.Split('='))
                .ToDictionary(p => HttpUtility.UrlDecode(p[0]), p => HttpUtility.UrlDecode(p[1]));
        }

        public static string BuildQueryString(IDictionary<string, string> form) =>
            string.Join("&", form.Select(item => $"{HttpUtility.UrlEncode(item.Key)}={HttpUtility.UrlEncode(item.Value)}"));

        public static string BuildQueryString(NameValueCollection form) =>
            string.Join("&", form.AllKeys.Select(key => $"{HttpUtility.UrlEncode(key)}={HttpUtility.UrlEncode(form[key])}"));

    }
}