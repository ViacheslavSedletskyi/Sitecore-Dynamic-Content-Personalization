﻿using System.Collections.Generic;
using System.Collections.Specialized;

namespace iData.Feature.CoveoSearch.HttpModule
{
    internal interface IFormRewriter
    {
        IDictionary<string, string> Rewrite(IDictionary<string, string> form);
    }
}