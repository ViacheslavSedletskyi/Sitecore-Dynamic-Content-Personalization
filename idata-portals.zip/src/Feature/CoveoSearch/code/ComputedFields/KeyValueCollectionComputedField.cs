﻿using Coveo.Framework.CNL;
using Coveo.Framework.Items;
using Coveo.Framework.Log;
using Coveo.SearchProvider.ComputedFields;
using Sitecore.ContentSearch;
using System.Linq;
using System.Reflection;
using System.Xml;
using System.Collections.Generic;
using Sitecore.Data.Items;
using Sitecore.Data;
using iData.Foundation.Sitecore.Extensions;
using Newtonsoft.Json;
using Coveo.Framework.Collections;

namespace iData.Feature.CoveoSearch.ComputedFields
{
    public class KeyValueCollectionComputedField : ReferencedFieldComputedField
    {
        private static readonly ILogger s_Logger = CoveoLogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        public string DestinationFieldName
        {
            get
            {
                return this.GetAttributeValue("destinationFieldName");
            }
        }

        public string ValueFieldNames
        {
            get
            {
                return this.GetAttributeValue("valueFieldNames");
            }
        }

        public ID[] AllowForTemplates
        {
            get
            {
                return ID.ParseArray(this.GetAttributeValue("executedForTemplates"));
            }
        }

        public KeyValueCollectionComputedField(XmlNode p_Configuration) : base(p_Configuration)
        {
        }

        public override object ComputeFieldValue(IIndexable p_Indexable)
        {
            Precondition.NotNull(p_Indexable, () => () => p_Indexable);

            return this.OverridenComputeFieldValue(new ItemWrapper(new IndexableWrapper(p_Indexable)));
        }

        public object OverridenComputeFieldValue(IItem p_Item)
        {
            Precondition.NotNull(p_Item, () => () => p_Item);

            if (CanProcess(p_Item.SitecoreItem))
            {
                s_Logger.TraceEntering($"ComputeFieldValue: {FieldName} start executing");

                if (!string.IsNullOrWhiteSpace(DestinationFieldName) && !string.IsNullOrWhiteSpace(ValueFieldNames))
                {
                    var obj = new List<Dictionary<string, string>>();

                    foreach (var destItemId in ID.ParseArray(p_Item.SitecoreItem[DestinationFieldName], false))
                    {
                        var destItem = p_Item.SitecoreItem.Database.GetItem(destItemId);
                        if (destItem != null)
                        {
                            var dicProperties = new Dictionary<string, string>();
                            
                            ValueFieldNames.Split(',').ForEach(fieldName => dicProperties.Add(fieldName.ToLowerInvariant(), destItem[fieldName]));

                            obj.Add(dicProperties);
                        }
                    }

                    return JsonConvert.SerializeObject(obj, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
                }

                return base.ComputeFieldValue(p_Item);
            }

            return null;
        }

        public virtual bool CanProcess(Item currentItem)
        {
            return currentItem.InheritsFrom(AllowForTemplates) || !AllowForTemplates.Any();
        }
    }
}