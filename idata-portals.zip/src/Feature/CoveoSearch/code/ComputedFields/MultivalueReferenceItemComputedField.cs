using System;
using System.Collections.Generic;
using Sitecore;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.ComputedFields;
using Sitecore.Data;
using Sitecore.Data.Fields;
using Sitecore.Data.Items;

namespace iData.Feature.CoveoSearch.ComputedFields
{
    public class MultivalueReferenceItemComputedField : IComputedIndexField
    {
        /// <inheritdoc />
        public string FieldName { get; set; }
        /// <inheritdoc />
        public string ReturnType { get; set; }
        /// <inheritdoc />
        public object ComputeFieldValue(IIndexable indexable)
        {
            Item thisItem = (Item)(indexable as SitecoreIndexableItem);
            string name = FieldName.Replace("idata_", "").Replace("_name", "").ToUpper();
            if (thisItem.Children["Metadata"] != null)
            {
                Item childItem = thisItem.Children["Metadata"].Children[name];

                Field multiValueField = childItem?.Fields["Values"];
                if (multiValueField != null)
                {
                    // The raw value of a Multilist field looks like this:
                    // {F90052A5-B4E6-4E6D-9812-1E1B88A6FCEA}|{F0D16EEE-3A05-4E43-A082-795A32B873C0}
                    // So we split it at the "|" character to retrieve the GUIDs.
                    string[] referencedItemGuids = multiValueField.Value.ToString().Split("|".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                    List<string> referencedItemNames = new List<string>();
                    foreach (string referencedItemGuid in referencedItemGuids)
                    {
                        // Then we retrieve the name of each item referenced by these GUIDs.
                        Item item = Context.ContentDatabase.GetItem(new ID(referencedItemGuid));
                        referencedItemNames.Add(item["Name"]);
                    }
                    // Finally, we join all those item names using the default separator (;) to get a properly-formatted field.
                    return String.Join(";", referencedItemNames.ToArray());
                }
            }
            return null;
        }
    }
}