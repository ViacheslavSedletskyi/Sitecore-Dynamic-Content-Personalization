﻿using System.Collections.Generic;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.ComputedFields;
using Sitecore.Data.Items;
using Sitecore.Data.Fields;
using iData.Foundation.Platform;
using iData.Foundation.Platform.Extensions;
using iData.Feature.CoveoSearch.ComputedFields.Models;
using System.Linq;
using iData.Foundation.Sitecore.Extensions;
using Sitecore.Links.UrlBuilders;
using Newtonsoft.Json;
using Sitecore.Globalization;

namespace iData.Feature.CoveoSearch.ComputedFields
{
    public class RelatedDocumentsComputedField : IComputedIndexField
    {
        /// <inheritdoc />
        public string FieldName { get; set; }
        /// <inheritdoc />
        public string ReturnType { get; set; }
        /// <inheritdoc />
        public object ComputeFieldValue(IIndexable indexable)
        {
            Item item = (Item)(indexable as SitecoreIndexableItem);

            if (item.TemplateID == Templates.Document.ID && item.FirstChildInheritingFrom(Templates.MediaVirtualFolder.ID).HasVirtualChildren())
            {
                var relatedDocuments = item.FirstChildInheritingFrom(Templates.MediaVirtualFolder.ID).GetVirtualChildren(true, true);
                Item[] predefinedDocumentFormats;

                using (new LanguageSwitcher(item.Language))
                {
                    predefinedDocumentFormats = item.Database.SelectItems($"/sitecore/catalog/*[@@templateid = '{Constants.DocumentFormatRootFolderId}']/*[@@templateid = '{Templates.DocumentFormat.ID}' and @UseInDialog = '1']");
                }
                
                var relatedDocumentObjectList = new List<RelatedDocumentObject>();

                foreach (MediaItem document in relatedDocuments)
                {
                    var currentDocumentFormatValue = (document.InnerItem.Fields[Constants.MediaItemFormatFieldName].HasValue ? document.InnerItem[Constants.MediaItemFormatFieldName] : document.Extension).ToUpper();

                    if (!document.InnerItem.Fields[Constants.MediaItemCountryCodeFieldName].HasValue || string.IsNullOrWhiteSpace(currentDocumentFormatValue))
                        continue;

                    if (!relatedDocumentObjectList.Any(doc => doc.FormatTypeName == currentDocumentFormatValue))
                    {
                        var predefinedDocumentFormat = predefinedDocumentFormats?.SingleOrDefault(docFormat => docFormat[Templates.DocumentFormat.Fields.Name].ToUpper() == currentDocumentFormatValue);

                        if (predefinedDocumentFormat == null) continue;

                        var internalRelatedDocumentObject = new RelatedDocumentObject() {
                            FormatId = predefinedDocumentFormat.ID,
                            FormatTypeName = currentDocumentFormatValue.ToUpper(), 
                            FormatTypeIcon = (ImageField)predefinedDocumentFormat.Fields[Templates.DocumentFormat.Fields.Icon],
                            Reference = new List<DocumentObject>() 
                        };

                        relatedDocumentObjectList.Add(internalRelatedDocumentObject);
                    }

                    var relatedDocumentObject = relatedDocumentObjectList.SingleOrDefault(doc => doc.FormatTypeName == currentDocumentFormatValue);

                    var documentObject = new DocumentObject() 
                    { 
                        LanguageIsoCode = document.InnerItem[Constants.MediaItemCountryCodeFieldName],
                        Size = document.Size,
                        Title = document.InnerItem[Constants.MediaItemCountryCodeFieldName],
                        Link = ((MediaItem)document).MediaUrl(new MediaUrlBuilderOptions() { AbsolutePath = false }),
                    };

                    relatedDocumentObject.Reference.Add(documentObject);
                }

                FillReferenceOnWebLinkDocument(ref relatedDocumentObjectList, item);

                return JsonConvert.SerializeObject(new RelatedDocuments() { Documents = relatedDocumentObjectList }, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
            }

            return null;
        }

        private void FillReferenceOnWebLinkDocument(ref List<RelatedDocumentObject> relatedDocumentObjectList, Item item)
        {

            if (item.Fields[Templates.Document.Fields.WebLink].HasValue)
            {
                var webLinkDocumentFormatItem = item.Database.GetItem(Constants.WebLinkDocumentFormatId);

                if (webLinkDocumentFormatItem != null)
                {
                    var documentFormatImageField = (ImageField)webLinkDocumentFormatItem.Fields[Templates.DocumentFormat.Fields.Icon];

                    var webLinkReference = new RelatedDocumentObject()
                    {
                        FormatId = webLinkDocumentFormatItem.ID,
                        FormatTypeName = webLinkDocumentFormatItem[Templates.DocumentFormat.Fields.Name],
                        FormatTypeIcon = documentFormatImageField,
                        Reference = new List<DocumentObject>() { 
                            new DocumentObject() { 
                                Link = item[Templates.Document.Fields.WebLink], 
                            } 
                        }
                    };

                    relatedDocumentObjectList.Add(webLinkReference);
                }
            }
        }
    }
}