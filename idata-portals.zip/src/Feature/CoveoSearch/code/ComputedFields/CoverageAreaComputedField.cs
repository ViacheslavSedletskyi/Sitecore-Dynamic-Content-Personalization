﻿using System;
using System.Collections.Generic;
using Sitecore;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.ComputedFields;
using Sitecore.Data.Items;
using Sitecore.Data;
using System.Linq;
using Newtonsoft.Json;
using iData.Feature.CoveoSearch.ComputedFields.Models;
using PlatformConstants = iData.Foundation.Platform.Constants;
using PlatformTemplates = iData.Foundation.Platform.Templates;
using iData.Foundation.Sitecore.Extensions;
using Sitecore.Diagnostics;

namespace iData.Feature.CoveoSearch.ComputedFields
{
    public class CoverageAreaComputedField : IComputedIndexField
    {
        /// <inheritdoc />
        public string FieldName { get; set; }
        /// <inheritdoc />
        public string ReturnType { get; set; }
        /// <inheritdoc />
        public object ComputeFieldValue(IIndexable indexable)
        {
            Item item = indexable as SitecoreIndexableItem;

            var referenceAreaMetadataFieldItem = item.Axes.SelectSingleItem($"./*[@@templateid='{PlatformTemplates.MetadataFolder.ID}']/*[@{PlatformConstants.MetadataFieldSourceProviderFieldName} = '{PlatformConstants.CL_REF_AREA_Folder_As_Source_Of_Metadata_Field}']");

            if (referenceAreaMetadataFieldItem != null)
            {
                var coverageAreaModelObject = new CoverageModel();
                
                var referenceAreaMetadataIds = ID.ParseArray(referenceAreaMetadataFieldItem[PlatformConstants.MetadataValueFieldName]);

                var orderedRefAreaItemsByCountryName = referenceAreaMetadataIds?.Select(id => Context.ContentDatabase.GetItem(id)).Where(e => e != null).OrderBy(refAreaItem => refAreaItem[PlatformTemplates.Glossary.Fields.Name]);

                coverageAreaModelObject.Coverage = CalculateComputedFieldValue(orderedRefAreaItemsByCountryName, item.Database);

                return JsonConvert.SerializeObject(coverageAreaModelObject);
            }

            return null;
        }

        public object ComputeFieldValueByEntitlements(string entitlementsDataKey, string[] entitlementsDataValue, Database currentDatabase)
        {
            Assert.ArgumentNotNull(currentDatabase, nameof(currentDatabase));

            var coverageAreaModelObject = new CoverageModel();

            var metadataFieldSearchString = $"/sitecore/catalog/*[@@templateid='{ PlatformTemplates.MetadataFieldsRootFolder.ID }']//*[@searchField='{ entitlementsDataKey }']";

            var glossaryMetadataFolderItem = currentDatabase.SelectSingleItem(metadataFieldSearchString)?.TargetItem(PlatformTemplates.MetadataField.Fields.GlossarySourceFolder.ToString());

            var orderedRefAreaItemsByCountryName = entitlementsDataValue.Select(dataValue => glossaryMetadataFolderItem?.Axes.SelectSingleItem($".//*[@@templateid='{ PlatformTemplates.Glossary.ID }' and @Name='{ dataValue }']"))
                                                        .Where(e => e != null).OrderBy(refAreaItem => refAreaItem[PlatformTemplates.Glossary.Fields.Name]);

            coverageAreaModelObject.Coverage = CalculateComputedFieldValue(orderedRefAreaItemsByCountryName, currentDatabase);

            return JsonConvert.SerializeObject(coverageAreaModelObject);
        }

        private IEnumerable<CoverageArea> CalculateComputedFieldValue(IOrderedEnumerable<Item> orderedRefAreaItemsByCountryName, Database currentDatabase) 
        {
            
            var coverageGroupList = new List<CoverageArea>();

            var coverageMapper = GetCoverageAreaMapper(currentDatabase);

            foreach (var referenceAreaItem in orderedRefAreaItemsByCountryName)
            {
                var coverageCountryObject = new CoverageCountry() { Name = referenceAreaItem[PlatformTemplates.Glossary.Fields.Name], Code = referenceAreaItem[PlatformTemplates.Glossary.Fields.Code] };

                var coverageGroupKey = coverageMapper.FirstOrDefault(x => x.Value.Contains(referenceAreaItem.ID)).Key;

                if (coverageGroupKey == null)
                    continue;

                if (coverageGroupList.FirstOrDefault(cArea => cArea.Group.Code == coverageGroupKey.Code && cArea.Group.Name == coverageGroupKey.Name) is CoverageArea cGroup)
                {
                    cGroup.Countries.Add(coverageCountryObject);
                }
                else
                {
                    var coverageArea = new CoverageArea() { Group = coverageGroupKey, Countries = new List<CoverageCountry>() };
                    coverageArea.Countries.Add(coverageCountryObject);

                    coverageGroupList.Add(coverageArea);
                }
            }

            return coverageGroupList;
        }

        private static Dictionary<CoverageGroup, ID[]> GetCoverageAreaMapper(Database database)
        {
            var output = new Dictionary<CoverageGroup, ID[]>();

            var coverageAreaGlossaryFolderItem = database.SelectSingleItem($"/sitecore/catalog/*[@@templateid='{PlatformConstants.GlossaryRepoFolderId}']/*[@@id='{PlatformConstants.CL_COVERAGE_AREA_Folder}']");
            
            if (coverageAreaGlossaryFolderItem != null)
            {
                foreach (Item childItem in coverageAreaGlossaryFolderItem.Children)
                {
                    var coverageGroup = new CoverageGroup() { Code = childItem[PlatformTemplates.Glossary.Fields.Code], Name = childItem[PlatformTemplates.Glossary.Fields.Name] };

                    output.Add(coverageGroup, ID.ParseArray(childItem[PlatformTemplates.GlossaryList.Fields.Values]));
                }
            }

            return output;
        }
    }
}