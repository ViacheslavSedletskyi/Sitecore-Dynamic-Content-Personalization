﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace iData.Feature.CoveoSearch.ComputedFields.Models
{
    [Serializable]
    public class CoverageModel
    {
        [JsonProperty("coverage")]
        public IEnumerable<CoverageArea> Coverage { get; set; }
    }
}