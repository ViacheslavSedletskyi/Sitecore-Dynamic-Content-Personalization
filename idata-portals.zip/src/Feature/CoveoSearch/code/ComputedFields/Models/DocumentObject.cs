﻿using Newtonsoft.Json;
using System;

namespace iData.Feature.CoveoSearch.ComputedFields.Models
{
    [Serializable]
    public class DocumentObject
    {
        [JsonProperty("lang_code")]
        public string LanguageIsoCode {get; set;}

        [JsonProperty("title")]
        public string Title { get; set; }

        [JsonProperty("sizeInBytes")]
        public long Size { get; set; }

        [JsonProperty("link")]
        public string Link { get; set; }

    }
}