﻿using iData.Foundation.Sitecore.Converters.Newtonsoft.Json;
using Newtonsoft.Json;
using Sitecore.Data;
using Sitecore.Data.Fields;
using System;
using System.Collections.Generic;

namespace iData.Feature.CoveoSearch.ComputedFields.Models
{
    [Serializable]
    public class RelatedDocumentObject
    {
        [JsonProperty("format_id"), JsonConverter(typeof(SitecoreIdValueConverter))]
        public ID FormatId { get; set; }

        [JsonProperty("format_name")]
        public string FormatTypeName { get; set; }

        [JsonProperty("icon"), JsonConverter(typeof(SvgMediaItemValueConverter))]
        public ImageField FormatTypeIcon { get; set; }

        [JsonProperty("tooltip")]
        public string FormatTooltip { get { return FormatTypeIcon?.Alt; } }

        [JsonProperty("references")]
        public List<DocumentObject> Reference { get; set; }
    }
}