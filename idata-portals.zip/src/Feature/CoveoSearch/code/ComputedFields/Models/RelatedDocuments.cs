﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace iData.Feature.CoveoSearch.ComputedFields.Models
{
    [Serializable]
    public class RelatedDocuments
    {
        [JsonProperty("documents")]
        public IEnumerable<RelatedDocumentObject> Documents { get; set; }
    }
}