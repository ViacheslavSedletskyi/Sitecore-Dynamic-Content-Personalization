﻿using Newtonsoft.Json;
using System;

namespace iData.Feature.CoveoSearch.ComputedFields.Models
{
    [Serializable]
    public class CoverageCountry
    {
        [JsonProperty("code")]
        public string Code { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }
    }
}