﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace iData.Feature.CoveoSearch.ComputedFields.Models
{
    [Serializable]
    public class CoverageArea
    {
        [JsonProperty("group")]
        public CoverageGroup Group { get; set; }

        [JsonProperty("items")]
        public List<CoverageCountry> Countries { get; set; }
    }
}