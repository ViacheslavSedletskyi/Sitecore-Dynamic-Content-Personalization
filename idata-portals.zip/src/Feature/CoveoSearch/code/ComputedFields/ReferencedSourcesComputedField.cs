﻿using Coveo.Framework.CNL;
using Coveo.Framework.Items;
using Coveo.Framework.Log;
using Coveo.SearchProvider.ComputedFields;
using Sitecore.ContentSearch;
using System.Linq;
using iData.Foundation.Platform.Extensions;
using System.Reflection;
using System.Xml;
using System.Collections.Generic;
using Sitecore.Data.Items;
using iData.Foundation.Platform;
using Sitecore.Data;
using iData.Foundation.Sitecore.Extensions;

namespace iData.Feature.CoveoSearch.ComputedFields
{
    public class ReferencedSourcesComputedField : ReferencedFieldComputedField
    {
        private static readonly ILogger s_Logger = CoveoLogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        public string SourceFolderPath
        {
            get
            {
                return this.GetAttributeValue("sourceFolderPath");
            }
        }

        public ID[] AllowForTemplates
        {
            get
            {
                return ID.ParseArray(this.GetAttributeValue("executedForTemplates"));
            }
        }

        public ReferencedSourcesComputedField(XmlNode p_Configuration) : base(p_Configuration)
        {
        }

        public override object ComputeFieldValue(IIndexable p_Indexable)
        {
            Precondition.NotNull(p_Indexable, () => () => p_Indexable);

            return this.OverridenComputeFieldValue(new ItemWrapper(new IndexableWrapper(p_Indexable)));
        }

        public object OverridenComputeFieldValue(IItem p_Item)
        {
            Precondition.NotNull(p_Item, () => () => p_Item);
            
            if (p_Item.SitecoreItem.InheritsFrom(AllowForTemplates) || !AllowForTemplates.Any())
            {
                s_Logger.TraceEntering($"ComputeFieldValue: {FieldName} start executing");

                if (!string.IsNullOrWhiteSpace(SourceFolderPath))
                {
                    object obj = null;

                    var destinationFolders = p_Item.SitecoreItem.Axes.SelectItems(SourceFolderPath);

                    if (destinationFolders != null && destinationFolders.Any())
                    {
                        var generatedValues = CollectAndAggregateValues(destinationFolders);

                        if (generatedValues.Any())
                        {
                            obj = string.Join(iData.Foundation.Platform.Constants.MetadataValuesSeparator, generatedValues);
                        }
                    }

                    return obj;
                }

                return base.ComputeFieldValue(p_Item);
            }

            return null;
        }

        private IEnumerable<string> CollectAndAggregateValues(IEnumerable<Item> destFolders)
        {
            var valueList = new List<string>();

            foreach(var folder in destFolders)
            {
                var destItemList = folder.TemplateID == Templates.MediaVirtualFolder.ID ? folder.GetVirtualChildren(true, true) : folder.Axes.GetDescendants();

                valueList.AddRange(destItemList.Select(childItem => GetFallbackReferenceFieldName(childItem)).Where(e => !string.IsNullOrEmpty(e)));
            }

            return valueList.Distinct();
        }

        private string GetFallbackReferenceFieldName(Item currentItem)
        {
            var referenceFieldNameWithFallback = ReferencedFieldName.Split(';');

            foreach(var refFieldName in referenceFieldNameWithFallback)
            {
                var value = currentItem[refFieldName];

                if (!string.IsNullOrWhiteSpace(value))
                    return value.ToUpper();
            }

            return string.Empty;
        }
    }
}