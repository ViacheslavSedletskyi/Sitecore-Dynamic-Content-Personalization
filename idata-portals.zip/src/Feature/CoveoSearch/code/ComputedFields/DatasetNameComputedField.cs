﻿using System;
using System.Collections.Generic;
using Sitecore;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.ComputedFields;
using Sitecore.Data.Items;
using Sitecore.Data;
using Sitecore.Data.Fields;


namespace iData.Feature.CoveoSearch.ComputedFields
{
    public class DatasetNameComputedField : IComputedIndexField
    {
        /// <inheritdoc />
        public string FieldName { get; set; }
        /// <inheritdoc />
        public string ReturnType { get; set; }
        /// <inheritdoc />
        public object ComputeFieldValue(IIndexable indexable)
        {
            Item item = (Item)(indexable as SitecoreIndexableItem);
            if (item.Template.Name.ToLower() == "dataset")
            {
                IIndexableDataField title = indexable.GetFieldByName("Title");
                return title.Value.ToString();
            }
            else if (item.Template.Name.ToLower() == "document" || item.TemplateName.Equals(iData.Foundation.Platform.Templates.News.TemplateName))
            {
                Field multiValueField = item.Fields["Datasets"];
                if (multiValueField != null)
                {
                    // The raw value of a Multilist field looks like this:
                    // {F90052A5-B4E6-4E6D-9812-1E1B88A6FCEA}|{F0D16EEE-3A05-4E43-A082-795A32B873C0}
                    // So we split it at the "|" character to retrieve the GUIDs.
                    string[] referencedItemGuids = multiValueField.Value.ToString().Split("|".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
                    List<string> referencedItemNames = new List<string>();
                    foreach (string referencedItemGuid in referencedItemGuids)
                    {
                        // Then we retrieve the name of each item referenced by these GUIDs.
                        Item i = Context.ContentDatabase.GetItem(new ID(referencedItemGuid));
                        referencedItemNames.Add(i["Title"]);
                    }
                    // Finally, we join all those item names using the default separator (;) to get a properly-formatted field.
                    return String.Join(";", referencedItemNames.ToArray());
                }
            }
            return null;
        }
    }
}