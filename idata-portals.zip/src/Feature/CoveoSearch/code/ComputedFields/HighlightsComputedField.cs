﻿using Sitecore.ContentSearch;
using Sitecore.ContentSearch.ComputedFields;
using Sitecore.Data.Items;
using iData.Foundation.Platform;
using System.Collections.Generic;
using iData.Foundation.Sitecore.Extensions;
using Sitecore.Data;
using iData.Foundation.Sitecore.Fields;
using System.Linq;
using PlatformConstants = iData.Foundation.Platform.Constants;
using Sitecore.Links;

namespace iData.Feature.CoveoSearch.ComputedFields
{
    public class HighlightsComputedField : IComputedIndexField
    {
        /// <inheritdoc />
        public string FieldName { get; set; }
        /// <inheritdoc />
        public string ReturnType { get; set; }
        /// <inheritdoc />
        public object ComputeFieldValue(IIndexable indexable)
        {
            var item = (Item)(indexable as SitecoreIndexableItem);

            if (item.InheritsFrom(Templates.Common._Highlights.ID))
            {
                 LinkListField linkedHighlightLinksField = item.Fields[Templates.Common._Highlights.Fields.LinkedHighlightLinks];

                if (linkedHighlightLinksField != null && linkedHighlightLinksField.Links.Any())
                {
                    var generatedLinkList = linkedHighlightLinksField.Links.Select(link => link.GetHyperlinkString()).Where(e => e != null);

                    return string.Join(PlatformConstants.MetadataValuesSeparator, generatedLinkList);
                }
            }

            return null;
        }
    }
}