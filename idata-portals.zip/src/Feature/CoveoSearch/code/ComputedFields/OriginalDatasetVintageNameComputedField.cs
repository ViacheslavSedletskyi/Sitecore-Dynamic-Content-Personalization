﻿using Sitecore.ContentSearch;
using Sitecore.ContentSearch.ComputedFields;
using Sitecore.Data.Items;
using iData.Foundation.ExternalStorage.Extensions;
using iData.Foundation.Platform;


namespace iData.Feature.CoveoSearch.ComputedFields
{
    public class OriginalDatasetVintageNameComputedField : IComputedIndexField
    {
        /// <inheritdoc />
        public string FieldName { get; set; }
        /// <inheritdoc />
        public string ReturnType { get; set; }
        /// <inheritdoc />
        public object ComputeFieldValue(IIndexable indexable)
        {
            Item item = (Item)(indexable as SitecoreIndexableItem);

            if (item.TemplateID == Templates.DatasetVintage.ID)
            {
                return item.GetAncestorOrSelfOfTemplate(Templates.Dataset.ID).Name;
            }

            return null;
        }
    }
}