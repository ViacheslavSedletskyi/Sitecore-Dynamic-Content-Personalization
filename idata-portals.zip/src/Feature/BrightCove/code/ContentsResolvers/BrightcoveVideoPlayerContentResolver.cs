﻿using Sitecore.Data;
using Sitecore.Diagnostics;
using Sitecore.LayoutService.Configuration;
using Sitecore.MediaFramework.Pipelines.MediaGenerateMarkup;
using Sitecore.MediaFramework.Players;
using System.Collections.Generic;
using System.Linq;
using Sitecore.Mvc.Presentation;
using Sitecore.Data.Items;
using iData.Feature.Brightcove.Constants;
using iData.Foundation.Platform.Helpers;

namespace iData.Feature.Brightcove.ContentsResolvers
{
    public class BrightcoveVideoPlayerContentResolver : Sitecore.LayoutService.ItemRendering.ContentsResolvers.RenderingContentsResolver
    {

        public override object ResolveContents(Rendering rendering, IRenderingConfiguration renderingConfig)
        {
            Assert.ArgumentNotNull(rendering, nameof(rendering));
            Assert.ArgumentNotNull(renderingConfig, nameof(renderingConfig));

            rendering.DataSource = DatasourceHelper.ResolveRenderingDatasource(rendering.DataSource);

            if (!IsValideDatasource(rendering.DataSource))
            {
                MediaGenerateMarkupArgs mediaGenerateMarkupArg = new MediaGenerateMarkupArgs();
                mediaGenerateMarkupArg.AbortPipeline();
                return mediaGenerateMarkupArg;
            }

            return MediaGenerateMarkupData(rendering, renderingConfig, rendering.DataSource);
        }

        public virtual bool IsValideDatasource(string itemID)
        {
            return IsVideoItem(itemID);
        }

        public virtual bool IsVideoItem(string itemID)
        {
            return ID.IsID(itemID) && IsItemTemplateEqualTo(new ID(itemID), BrightcoveTemplates.BrightcoveVideo.TemplateID);
        }

        protected virtual bool IsItemTemplateEqualTo(ID itemID, ID templateID)
        {
            Item dsItem = Sitecore.Context.Database.GetItem(itemID);

            return dsItem != null && dsItem.TemplateID == templateID;
        }

        public virtual object MediaGenerateMarkupData(Rendering rendering, IRenderingConfiguration renderingConfig, string itemID)
        {
            return MediaGenerateItemMarkupData(rendering, renderingConfig, itemID);
        }

        public virtual object MediaGenerateItemMarkupData(Rendering rendering, IRenderingConfiguration renderingConfig, string itemID)
        {
            PlayerProperties playerProperty = null;

            if(string.IsNullOrEmpty(itemID))
            {
                playerProperty = new PlayerProperties();
            }
            else
            {
                playerProperty = new PlayerProperties(rendering.Parameters.ToDictionary((KeyValuePair<string, string> p) => p.Key, (KeyValuePair<string, string> p) => p.Value))
                {
                    ItemId = new ID(itemID)
                };
            }

            MediaGenerateMarkupArgs mediaGenerateMarkupArg1 = new MediaGenerateMarkupArgs()
            {
                MarkupType = MarkupType.Html,
                Properties = playerProperty
            };

            if (!string.IsNullOrEmpty(itemID))
            {
                MediaGenerateMarkupPipeline.Run(mediaGenerateMarkupArg1);
            }

            mediaGenerateMarkupArg1.Database = null;

            return new
            {
                markupType = mediaGenerateMarkupArg1.MarkupType,
                playerProperties = mediaGenerateMarkupArg1.Properties,
                mediaItem = mediaGenerateMarkupArg1.MediaItem != null ? ProcessItem(mediaGenerateMarkupArg1.MediaItem,
                                                                             rendering,
                                                                             renderingConfig) : null,
                playerItem = mediaGenerateMarkupArg1.MediaItem != null ? ProcessItem(mediaGenerateMarkupArg1.PlayerItem,
                                                                              rendering,
                                                                              renderingConfig) : null,
                PlayerMarkupResult = mediaGenerateMarkupArg1.Result,
                linkTitle = mediaGenerateMarkupArg1.LinkTitle,
                playbackEvents = mediaGenerateMarkupArg1.PlaybackEvents,
                result = mediaGenerateMarkupArg1.Result,
                publisherId = mediaGenerateMarkupArg1.AccountItem == null ? 
                    "" : mediaGenerateMarkupArg1.AccountItem.Fields[BrightcoveTemplates.Account.PublisherIdFiedName]?.Value
            };
        }
    }
}