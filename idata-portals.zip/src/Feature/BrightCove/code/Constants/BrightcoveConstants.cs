﻿using Sitecore.Data;

namespace iData.Feature.Brightcove.Constants
{
    public struct BrightcoveTemplates
    {
        public struct BrightcoveVideo
        {
            public static readonly ID TemplateID = new ID("{6A5C6835-6E11-4602-A11D-B626E9255397}");
        }

        public struct Account
        {
            public const string PublisherIdFiedName = "PublisherID";
        }
    }
}