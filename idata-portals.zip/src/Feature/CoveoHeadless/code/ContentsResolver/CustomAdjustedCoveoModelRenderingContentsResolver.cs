﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore.LayoutService.Configuration;
using Sitecore.Data.Items;
using Sitecore.Mvc.Presentation;
using System.Reflection;
using Sitecore.Data.Fields;
using iData.Feature.CoveoHeadless.Coveo.Jss;
using iData.Foundation.Platform.Helpers;

namespace iData.Feature.CoveoHeadless.ContentsResolver
{
    public class CustomAdjustedCoveoModelRenderingContentsResolver : Sitecore.LayoutService.ItemRendering.ContentsResolvers.RenderingContentsResolver
    {
        private readonly static string LOG_PREFIX;

        private readonly static Lazy<CoveoJssRenderings> ConfigRenderings;

        static CustomAdjustedCoveoModelRenderingContentsResolver()
        {
            LOG_PREFIX = "MODELRENDERING:";
            ConfigRenderings = new Lazy<CoveoJssRenderings>(new Func<CoveoJssRenderings>(ReadCoveoJssRenderings));
        }

        public CustomAdjustedCoveoModelRenderingContentsResolver()
        {
        }

        private static object ConvertHtmlStringPropertiesToString(object properties)
        {
            Type type;
            object str;
            IDictionary<string, object> strs = new Dictionary<string, object>();
            PropertyInfo[] propertyInfoArray = properties.GetType().GetProperties();
            for (int i = 0; i < (int)propertyInfoArray.Length; i++)
            {
                PropertyInfo propertyInfo = propertyInfoArray[i];
                IDictionary<string, object> strs1 = strs;

                string lowerCaseFirstLetter = LowerCaseFirstLetter(propertyInfo.Name);
                object value = null;
                try
                {
                    value = propertyInfo.GetValue(properties);
                }
                catch (Exception ex)
                {
                    strs1[lowerCaseFirstLetter] = null;
                    LogError(string.Concat("Could not GetValue of model property ", propertyInfo.Name + " Exception : " + ex.ToString()));
                    continue;
                }
                if (value != null)
                {
                    type = value.GetType();
                }
                else
                {
                    type = null;
                }
                if (type == typeof(HtmlString))
                {
                    str = value.ToString();
                }
                else
                {
                    str = value;
                }
                strs1[lowerCaseFirstLetter] = str;
            }
            return strs;
        }
        
        private static object CreateModel(Type modelType)
        {
            object baseComponentModel;
            ConstructorInfo constructor = modelType.GetConstructor(Array.Empty<Type>());
            if (constructor == null)
            {
                LogError(string.Concat("Model class ", modelType.FullName, " is missing a parameterless constructor."));
                return null;
            }
            try
            {
                baseComponentModel = (object)constructor.Invoke(Array.Empty<object>());
            }
            catch (Exception exception)
            {
                LogError(string.Concat("Could not instantiate model ", modelType.FullName + " Exception : " + exception.ToString()));
                return null;
            }
            return baseComponentModel;
        }

        private static string DictToString(IDictionary<string, object> p_Object)
        {
            return string.Join(" ,",
                from a in p_Object
                select string.Format("{0}:{1}", a.Key, a.Value));
        }

        private static Item GetHiveDataSourceItem(Rendering rendering)
        {
            BaseItem item;
            string value;
            if (rendering.RenderingItem != null)
            {
                item = rendering.RenderingItem.Database.GetItem(rendering.DataSource);
            }
            else
            {
                item = null;
            }

            Field field = null;

            if (item != null)
            {
                field = item.Fields["hiveDataSource"];
            }

            if (field != null)
            {
                value = field.Value;
            }
            else
            {
                value = null;
            }
            
            if (rendering.RenderingItem == null || string.IsNullOrWhiteSpace(value))
            {
                return null;
            }
            return rendering.RenderingItem.Database.GetItem(value);
        }

        private static void LogError(string p_Message)
        {
            Sitecore.Diagnostics.Log.Error(p_Message.ToString(), typeof(CustomAdjustedCoveoModelRenderingContentsResolver));
        }

        private static void LogDebug(string p_Message)
        {
            Sitecore.Diagnostics.Log.Debug(p_Message.ToString(), typeof(CustomAdjustedCoveoModelRenderingContentsResolver));
        }

        private static string LowerCaseFirstLetter(string source)
        {
            return string.Concat(source.Substring(0, 1).ToLower(), source.Substring(1));
        }

        private static CoveoJssRenderings ReadCoveoJssRenderings()
        {
            return Sitecore.Configuration.Factory.CreateObject<CoveoJssRenderings>(
                    Sitecore.Configuration.Factory.GetConfigNode("coveo/jssRenderingsCustom")
                );
        }

        public override object ResolveContents(Rendering rendering, IRenderingConfiguration renderingConfig)
        {
            Type modelType;
            RenderingSubModelDefinition[] renderingSubModelDefinitionArray;
            Type type1;
            string[] excludedFields;
            RenderingSubModelDefinition[] renderingSubModelDefinitionArray1;
            string renderingItemId;
            string renderingItemName;
            string[] excludedFieldsRes;
            
            if (string.IsNullOrEmpty(rendering.DataSource))
            {
                LogError("DataSource must be configured.");
            }

            RenderingItem renderingItem = rendering.RenderingItem;
            if (rendering.RenderingItem != null)
            {
                renderingItemId = rendering.RenderingItem.ID.ToString();
            }
            else
            {
                renderingItemId = null;
            }
            
            if (rendering.RenderingItem != null)
            {
                renderingItemName = rendering.RenderingItem.Name;
            }
            else
            {
                renderingItemName = null;
            }

            LogDebug(string.Concat(new string[] { LOG_PREFIX, " Finding Rendering Model for `", renderingItemId, "`. Trying with renderingItemName `", renderingItemName, "`." }));

            try
            {
                ConfigRenderings.Value.GetRenderingDefinition(renderingItemName).Deconstruct(out type1, out excludedFields, out renderingSubModelDefinitionArray1);
                modelType = type1;
                excludedFieldsRes = excludedFields;
                renderingSubModelDefinitionArray = renderingSubModelDefinitionArray1;
            }
            catch (InvalidOperationException invalidOperationException)
            {
                LogDebug(string.Concat(LOG_PREFIX, " Finding Rendering Model for `", renderingItemId, "`. No Rendering Model found by renderingItemName, trying with id."));
                
                ConfigRenderings.Value.GetRenderingDefinition(renderingItemId).Deconstruct(out type1, out excludedFields, out renderingSubModelDefinitionArray1);
                
                modelType = type1;
                excludedFieldsRes = excludedFields;
                renderingSubModelDefinitionArray = renderingSubModelDefinitionArray1;
            }
            LogDebug(string.Concat(LOG_PREFIX, " model has properties: ", string.Join(", ",
                from prop in (IEnumerable<PropertyInfo>)modelType.GetProperties()
                select prop.Name)));

            LogDebug(string.Concat(LOG_PREFIX, " excluding the following properties: ", string.Join(", ", excludedFieldsRes)));
            LogDebug(string.Concat(LOG_PREFIX, " ModelType ", modelType.FullName));
            
            Item hiveDataSourceItem = GetHiveDataSourceItem(rendering);

            LogDebug(string.Concat(LOG_PREFIX, " dataSourceItem was found? ", (hiveDataSourceItem != null ? "yes" : "no")));
            
            Dictionary<string, object> strs = SerializeWithHiveModel(modelType, rendering, excludedFieldsRes);

            LogDebug(string.Concat(LOG_PREFIX, " serializing sub models: ", string.Join(", ",
                from model in (IEnumerable<RenderingSubModelDefinition>)renderingSubModelDefinitionArray
                select model.Name)));
            
            strs["subModels"] = WrapValue(((IEnumerable<RenderingSubModelDefinition>)renderingSubModelDefinitionArray)
                .ToDictionary<RenderingSubModelDefinition, string, Dictionary<string, object>>(
                    (RenderingSubModelDefinition subModel) => 
                        subModel.Name, (RenderingSubModelDefinition subModel) => 
                        SerializeWithHiveModel(subModel.ModelType, rendering, excludedFieldsRes)
                ));

            LogDebug(string.Concat(LOG_PREFIX, " returning fields ", DictToString(strs)));
            return strs;
        }

        private static Dictionary<string, object> SerializeWithHiveModel(Type modelType, Rendering rendering,  string[] excludedProperties)
        {
            Func<PropertyInfo, bool> func = (PropertyInfo prop) => !excludedProperties.Contains<string>(prop.Name);
            
            object baseComponentModel = CreateModel(modelType);
            
            LogDebug(string.Concat(LOG_PREFIX, " model initialize"));

            var initMethod = modelType.GetMethod("Initialize", new[] { typeof(Rendering) });
            
            bool modelInitialized = false;
            
            if (initMethod != null)
            {
                try
                {
                    rendering.DataSource = DatasourceHelper.ResolveRenderingDatasource(rendering.DataSource);
                    
                    initMethod.Invoke(baseComponentModel, new object[] { (object)rendering });
                    modelInitialized = true;
                }
                catch (Exception ex)
                {
                    modelInitialized = false;
                    LogDebug(string.Concat(LOG_PREFIX, string.Format( " model initialization error : {0}"), ex.ToString()));
                }
            }
            
            Dictionary<string, object> resultJson = new Dictionary<string, object>();

            if (!modelInitialized)
            {
                return resultJson;
            }

            LogDebug(string.Concat(LOG_PREFIX, " model finished"));

            PropertyInfo[] properties = modelType.GetProperties();
            
            foreach (PropertyInfo propertyInfo in ((IEnumerable<PropertyInfo>)properties).Where<PropertyInfo>(func))
            {
                object propValue = null;
                try
                {
                    propValue = propertyInfo.GetValue(baseComponentModel);
                }
                catch (Exception ex)
                {
                    propValue = null;
                    LogDebug(string.Concat(LOG_PREFIX, string.Format(" property {0} get error : {1}"), propertyInfo.Name.ToString(), ex.ToString()));
                }

                resultJson[LowerCaseFirstLetter(propertyInfo.Name)] = 
                    (propertyInfo.Name == "Properties" ? 
                    WrapValue(ConvertHtmlStringPropertiesToString(propValue)) 
                    : 
                    WrapValue(propValue));
            }
            return resultJson;
        }

        private static string StringDictToString(IDictionary<string, string> p_Object)
        {
            return string.Join(" ,",
                from a in p_Object
                select string.Concat(a.Key, ":", a.Value));
        }

        private static object WrapValue(object value)
        {
            return new { @value = value };
        }
    }
}