﻿using Sitecore.LayoutService.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using Sitecore.Data.Items;
using Sitecore.Diagnostics;
using Sitecore.Data;
using Sitecore.Globalization;
using iData.Feature.CoveoHeadless.Constants;
using Newtonsoft.Json.Linq;
using Sitecore.Mvc.Presentation;
using System.Reflection;
using iData.Foundation.Platform.Helpers;

namespace iData.Feature.CoveoHeadless.ContentsResolver
{
    public class CoveoHeadlessContentsResolver : Sitecore.LayoutService.ItemRendering.ContentsResolvers.RenderingContentsResolver
    {
        private const string VisibleTextCapsLabel = "VisibleText";
        private const string VisibleTextLowercaseLabel = "visibleText";
        private const string RawPropertiesCapsLabel = "RawProperties";
        private const string RawPropertiesLowercaseLabel = "rawProperties";
        private const string HasFilterCapsLabel = "HasFilter";
        private const string HasFilterLowercaseLabel = "hasFilter";
        private const string ValueLowercaseLabel = "value";
        private const string PropertiesCapsLabel = "Properties";
        private const string ScriptCapsLabel = "Script";
        private const string ScriptLowercaseLabel = "script";
        private const string SubmodelsLabel = "Submodels";
        private const string ModelsLabel = "Model";
        private const string InitializeMethodName = "Initialize";
        private const string CssClassCapsLabel = "CssClass";
        private const string SearchPageUriLowercaseLabel = "searchPageUri";
        private const string SearchPageUriCapsLabel = "SearchPageUri";
        private const string OverrideSearchHubLowercaseLabel = "overrideSearchHub";
        private const string OverrideSearchHubCapsLabel = "OverrideSearchHub";
        private const string NewFakeItemNameLabel = "NewFakeItemName";


        public CoveoHeadlessContentsResolver() : base()
        {

        }

        public override object ResolveContents(Sitecore.Mvc.Presentation.Rendering rendering, IRenderingConfiguration renderingConfig)
        {
            Assert.ArgumentNotNull(rendering, nameof(rendering));
            Assert.ArgumentNotNull(renderingConfig, nameof(renderingConfig));

            Item ds = GetContextItem(rendering, renderingConfig);


            Item item = (ds == null) ? null : Sitecore.Context.Database.GetItem(new ID(ds.ID.ToString()));

            var articleModelRef = MapItemToRenderingModelItemRef(item, rendering, rendering.Parameters);

            var jObject = base.ProcessItem(articleModelRef, rendering, renderingConfig);
            return jObject;
        }

        private Item MapItemToRenderingModelItemRef(Item item, Rendering rendering, RenderingParameters parameters = null)
        {
            bool hasFilter = false;

            string visibleText = string.Empty;

            string resultItemScript = string.Empty;

            string cssClass = string.Empty;

            string searchPageUri = string.Empty;

            string overrideSearchHub = string.Empty;

            var newId = new ID();
            var def = new ItemDefinition(newId, item?.Name ?? NewFakeItemNameLabel, new ID(Templates.BaseCoveoHeadlessWithSubmodels.TemplateId.TemplateIdString), ID.Null);

            var fields = new FieldList();

            fields = AddItemIdAndHiveDatasourceFields(fields, item);


            Dictionary<string, string> keyValuePairs = GetParameters(rendering);

            Type modelType = GetModelType(keyValuePairs);

            PropertyInfo[] modelProps = GetModelProps(modelType);

            object model = GetAndInitializeModel(modelType, rendering);

            var submodelsEntries = ProcessSubmodels(keyValuePairs, rendering, ref hasFilter, ref visibleText);


            fields = ProcessSubmodelsEntries(fields, submodelsEntries);

            cssClass = GetCssClass(parameters, item, cssClass);

            fields = ProcessCssClass(fields, modelProps, ref cssClass, model, ref resultItemScript);

            fields = ProcessModelProperties(fields, modelProps, model, ref hasFilter, ref visibleText, ref resultItemScript, ref searchPageUri, ref overrideSearchHub);

            fields = ProcessModelRawProperties(fields, modelProps, model, ref resultItemScript, ref searchPageUri, ref overrideSearchHub);

            var data = new ItemData(def, Language.Current, Sitecore.Data.Version.First, fields);
            var db = (Sitecore.Context.Database ?? rendering?.RenderingItem?.Database) ?? Sitecore.Configuration.Factory.GetDatabase("web");

            var resultItem = new Item(newId, data, db);
            return resultItem;
        }

        private FieldList ProcessCssClass(FieldList fields, PropertyInfo[] modelProperties, ref string cssClass, object modelObj, ref string resultItemScript)
        {
            if (modelProperties == null || modelObj == null)
            {
                return new FieldList();
            }

            if (fields == null)
            {
                fields = new FieldList();
            }

            try
            {
                if (modelObj != null &&
                    modelProperties != null &&
                    modelProperties.Length > 0 &&
                    string.IsNullOrWhiteSpace(resultItemScript))
                {
                    var cssClassProp = new object();

                    if (modelProperties.Where(x => x.Name.Equals(CssClassCapsLabel)).ToList().FirstOrDefault() != null)
                    {
                        cssClassProp = modelProperties.Where(x => x.Name.Equals(CssClassCapsLabel)).ToList().First().GetValue(modelObj);

                        if (!string.IsNullOrWhiteSpace(cssClassProp?.ToString()))
                        {
                            cssClass += cssClassProp.ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Sitecore.Diagnostics.Log.Error(ex.ToString(), this);
            }

            if (!string.IsNullOrWhiteSpace(cssClass) && string.IsNullOrWhiteSpace(resultItemScript))
            {
                fields.Add(Templates.BaseCoveoHeadlessWithSubmodels.Fields.CssClassFieldId, cssClass);
            }

            return fields;
        }

        private FieldList ProcessSubmodelsEntries(FieldList fields, Dictionary<string, object> keyValuePairsInput)
        {
            if (fields == null)
            {
                fields = new FieldList();
            }

            try
            {
                if (keyValuePairsInput != null)
                {
                    var serializedSubmodels = Newtonsoft.Json.JsonConvert.SerializeObject(keyValuePairsInput);
                    fields.Add(Templates.BaseCoveoHeadlessWithSubmodels.Fields.SubModelsFieldId, serializedSubmodels);
                }
            }
            catch (Exception ex)
            {
                Sitecore.Diagnostics.Log.Error(ex.ToString(), this);
                return fields;
            }
            return fields;
        }

        private string GetCssClass(RenderingParameters renderingParameters, Item item, string cssClass)
        {
            if (string.IsNullOrWhiteSpace(cssClass))
            {
                cssClass = string.Empty;
            }

            try
            {
                if (item?.Fields[Templates.BaseCoveoHeadlessWithSubmodels.Fields.CssClassFieldName] != null && item.Fields[Templates.BaseCoveoHeadlessWithSubmodels.Fields.CssClassFieldName].HasValue)
                {
                    cssClass += item.Fields[Templates.BaseCoveoHeadlessWithSubmodels.Fields.CssClassFieldName].Value;
                }

                if (renderingParameters != null && !string.IsNullOrWhiteSpace(renderingParameters[Templates.CoveoParametersTemplate.Fields.CssClassFieldName]))
                {
                    cssClass += renderingParameters[Templates.CoveoParametersTemplate.Fields.CssClassFieldName];
                }
            }
            catch (Exception ex)
            {
                Sitecore.Diagnostics.Log.Error(ex.ToString(), this);
                return cssClass;
            }
            return cssClass;
        }

        private FieldList ProcessModelRawProperties(FieldList fields, PropertyInfo[] modelProperties, object modelObj,
            ref string resultItemScript, ref string searchPageUri, ref string overrideSearchHub)
        {
            if (modelProperties == null || modelObj == null)
            {
                return new FieldList();
            }

            if (fields == null)
            {
                fields = new FieldList();
            }

            try
            {
                if (modelObj != null && modelProperties != null && modelProperties.Length > 0)
                {
                    var rawProperties = new object();

                    if (modelProperties.Where(x => x.Name.Equals(RawPropertiesCapsLabel)).ToList().FirstOrDefault() != null)
                    {
                        rawProperties = modelProperties.Where(x => x.Name.Equals(RawPropertiesCapsLabel)).ToList().First().GetValue(modelObj);

                        if (rawProperties != null)
                        {
                            string serializedRawProperties = Newtonsoft.Json.JsonConvert.SerializeObject(
                                rawProperties,
                                modelProperties.Where(x => x.Name.Equals(PropertiesCapsLabel)).ToList().First().PropertyType,
                                new Newtonsoft.Json.JsonSerializerSettings()
                                {
                                    Formatting = Newtonsoft.Json.Formatting.None,
                                    StringEscapeHandling = Newtonsoft.Json.StringEscapeHandling.EscapeNonAscii,
                                    ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore,
                                    NullValueHandling = Newtonsoft.Json.NullValueHandling.Ignore,
                                }) ?? string.Empty;

                            if (!string.IsNullOrEmpty(resultItemScript))
                            {
                                var jsonRaw = JObject.Parse(serializedRawProperties);
                                jsonRaw[ScriptLowercaseLabel] = resultItemScript;

                                serializedRawProperties = jsonRaw.ToString();
                            }

                            if (!string.IsNullOrWhiteSpace(searchPageUri))
                            {
                                var jsonRaw = JObject.Parse(serializedRawProperties);
                                jsonRaw[SearchPageUriLowercaseLabel] = searchPageUri;

                                serializedRawProperties = jsonRaw.ToString();
                            }

                            if (!string.IsNullOrWhiteSpace(overrideSearchHub))
                            {
                                var jsonRaw = JObject.Parse(serializedRawProperties);
                                jsonRaw[OverrideSearchHubLowercaseLabel] = overrideSearchHub;

                                serializedRawProperties = jsonRaw.ToString();
                            }

                            fields.Add(Templates.BaseCoveoHeadlessWithSubmodels.Fields.RawPropertiesFieldId, serializedRawProperties);
                            fields.Add(Templates.BaseCoveoHeadlessWithSubmodels.Fields.PropertiesFieldId, serializedRawProperties);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Sitecore.Diagnostics.Log.Error(ex.ToString(), this);
                return fields;
            }

            return fields;
        }

        private FieldList ProcessModelProperties(FieldList fields, PropertyInfo[] modelProperties, object modelObj,
            ref bool hasFilter, ref string visibleText, ref string resultItemScript, ref string searchPageUri, ref string overrideSearchHub)
        {
            if (modelProperties == null || modelObj == null)
            {
                return new FieldList();
            }

            if (fields == null)
            {
                fields = new FieldList();
            }

            try
            {
                var properties = new object();

                if (modelProperties.Where(x => x.Name.Equals(PropertiesCapsLabel)).ToList().FirstOrDefault() != null)
                {
                    var prop = modelProperties.Where(x => x.Name.Equals(PropertiesCapsLabel)).ToList().FirstOrDefault();

                    properties = prop.GetValue(modelObj, BindingFlags.GetProperty | BindingFlags.FlattenHierarchy, null, new object[] { }, null);

                    if (hasFilter || modelProperties.Where(x => x.Name.Equals(HasFilterCapsLabel)).ToList().FirstOrDefault()?.GetValue(modelObj) != null)
                    {
                        if (!hasFilter)
                        {
                            hasFilter = (bool)modelProperties.Where(x => x.Name.Equals(HasFilterCapsLabel)).ToList().FirstOrDefault()?.GetValue(modelObj);
                        }

                        fields.Add(Templates.BaseCoveoHeadlessWithSubmodels.Fields.HasFilterFieldId, Newtonsoft.Json.JsonConvert.SerializeObject(hasFilter.ToString()));
                    }

                    if (!string.IsNullOrWhiteSpace(visibleText) || modelProperties.Where(x => x.Name.Equals(VisibleTextCapsLabel)).ToList().FirstOrDefault()?.GetValue(modelObj) != null)
                    {
                        if (string.IsNullOrWhiteSpace(visibleText))
                        {
                            visibleText = modelProperties.Where(x => x.Name.Equals(VisibleTextCapsLabel)).ToList().FirstOrDefault()?.GetValue(modelObj)?.ToString();
                        }

                        fields.Add(Templates.BaseCoveoHeadlessWithSubmodels.Fields.VisibleTextFieldId, Newtonsoft.Json.JsonConvert.SerializeObject(visibleText));
                    }

                    if (properties != null)
                    {
                        var propsInner = prop.PropertyType.GetProperties();

                        var searchPageUriValue = propsInner.Where(x => x.Name.Equals(SearchPageUriCapsLabel)).ToList().FirstOrDefault()?.GetValue(properties)?.ToString();

                        if (!string.IsNullOrWhiteSpace(searchPageUriValue))
                        {
                            searchPageUri = searchPageUriValue;
                            //fields.Add(Templates.BaseCoveoHeadlessWithSubmodels.Fields.SearchPageUriFieldId, Newtonsoft.Json.JsonConvert.SerializeObject(searchPageUri));
                        }

                        var overrideSearchHubValue = propsInner.Where(x => x.Name.Equals(OverrideSearchHubCapsLabel)).ToList().FirstOrDefault()?.GetValue(properties)?.ToString();

                        if (!string.IsNullOrWhiteSpace(overrideSearchHubValue))
                        {
                            overrideSearchHub = overrideSearchHubValue;
                        }

                        resultItemScript = propsInner.Where(x => x.Name.Equals(ScriptCapsLabel)).ToList().FirstOrDefault()?.GetValue(properties)?.ToString();
                    }
                }
                return fields;
            }
            catch (Exception ex)
            {
                Sitecore.Diagnostics.Log.Error(ex.ToString(), this);
                return fields;
            }
        }

        private Dictionary<string, object> ProcessSubmodels(Dictionary<string, string> keyValuePairsInput, Rendering rendering, ref bool hasFilter, ref string visibleText)
        {
            if (keyValuePairsInput == null || rendering == null)
            {
                return new Dictionary<string, object>();
            }

            var resultDictionary = new Dictionary<string, object>();
            try
            {
                var submodelsList = GetSubmodelsList(keyValuePairsInput);

                if (submodelsList.Count > 0)
                {
                    foreach (var submodelTypeElem in submodelsList)
                    {
                        var submodelType = Type.GetType(submodelTypeElem);

                        var submodelInst = GetAndInitializeModel(submodelType, rendering);

                        var nameOfComponent = submodelType?.Name?.Replace(ModelsLabel, "");

                        if (!string.IsNullOrWhiteSpace(nameOfComponent) && nameOfComponent.Length > 1)
                        {
                            nameOfComponent = Char.ToLowerInvariant(nameOfComponent[0]) + nameOfComponent.Substring(1);
                        }

                        var submodelProps = GetModelProps(submodelType);

                        var submodelDict = ProcessSubmodelProperties(submodelProps, nameOfComponent, submodelInst, ref hasFilter, ref visibleText);

                        foreach (var entry in submodelDict)
                        {
                            if (!resultDictionary.ContainsKey(entry.Key))
                            {
                                resultDictionary.Add(entry.Key, entry.Value);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Sitecore.Diagnostics.Log.Error(ex.ToString(), this);
            }

            return resultDictionary;
        }

        private Dictionary<string, object> ProcessSubmodelProperties(PropertyInfo[] submodelsPropeties, string componentName, object submodelObject, ref bool hasFilter, ref string visibleText)
        {
            var resultDict = new Dictionary<string, object>() { };

            if (string.IsNullOrWhiteSpace(componentName) || submodelsPropeties == null || submodelObject == null)
            {
                return resultDict;
            }

            if (submodelsPropeties.Where(x => x.Name.Equals(RawPropertiesCapsLabel)).ToList().First() != null && submodelsPropeties.Where(x => x.Name.Equals(RawPropertiesCapsLabel)).ToList().First().GetValue(submodelObject) != null)
            {
                var submodelRawProps = submodelsPropeties.Where(x => x.Name.Equals(RawPropertiesCapsLabel)).ToList().First().GetValue(submodelObject);

                if (submodelRawProps != null)
                {
                    var hasFilterSubmodel = false;
                    string visibleTextSubmodel = string.Empty;

                    if (submodelsPropeties.Where(x => x.Name.Equals(HasFilterCapsLabel)).ToList().FirstOrDefault()?.GetValue(submodelObject) != null)
                    {
                        hasFilterSubmodel = (bool)submodelsPropeties.Where(x => x.Name.Equals(HasFilterCapsLabel)).ToList().FirstOrDefault()?.GetValue(submodelObject);
                    }

                    if (submodelsPropeties.Where(x => x.Name.Equals(VisibleTextCapsLabel)).ToList().FirstOrDefault()?.GetValue(submodelObject) != null)
                    {
                        visibleTextSubmodel = submodelsPropeties.Where(x => x.Name.Equals(VisibleTextCapsLabel)).ToList().FirstOrDefault()?.GetValue(submodelObject)?.ToString();
                        if (!string.IsNullOrWhiteSpace(visibleTextSubmodel))
                        {
                            visibleText = visibleTextSubmodel;
                        }
                    }

                    var serializedRaw = Newtonsoft.Json.JsonConvert.SerializeObject(submodelRawProps);

                    JObject json = new JObject();

                    hasFilter = hasFilterSubmodel;
                    var jsonRaw = new JObject();

                    jsonRaw[RawPropertiesLowercaseLabel] = new JObject { { ValueLowercaseLabel, JToken.FromObject(submodelRawProps) } };
                    if (hasFilterSubmodel)
                    {
                        jsonRaw[HasFilterLowercaseLabel] = new JObject { { ValueLowercaseLabel, hasFilterSubmodel } };
                    }

                    if (!string.IsNullOrWhiteSpace(visibleTextSubmodel))
                    {
                        jsonRaw[VisibleTextLowercaseLabel] = new JObject { { ValueLowercaseLabel, visibleTextSubmodel } };
                    }

                    json = jsonRaw;

                    resultDict.Add(componentName, json);
                }
            }
            return resultDict;
        }

        private Dictionary<string, string> GetParameters(Rendering rendering)
        {
            if (rendering.RenderingItem != null && !string.IsNullOrWhiteSpace(rendering.RenderingItem.Parameters))
            {
                var keyValuePairsParsed = rendering.RenderingItem.Parameters.Split('&')
                    .Select(value => value.Split('='))
                    .ToDictionary(pair => pair[0], pair => pair.Count() == 1 ? "" : pair[1] ?? "");

                return keyValuePairsParsed;
            }

            return new Dictionary<string, string>();
        }

        private List<string> GetSubmodelsList(Dictionary<string, string> keyValuePairsDict)
        {

            if (keyValuePairsDict == null
                || keyValuePairsDict.Count <= 0
                || !keyValuePairsDict.ContainsKey(SubmodelsLabel)
                || keyValuePairsDict[SubmodelsLabel] == null)
            {
                return new List<string>();
            }

            try
            {
                var submodelsInnerList = keyValuePairsDict[SubmodelsLabel]
                 .Split(';')
                 .Where(x => !string.IsNullOrWhiteSpace(x))
                 .ToList();

                return submodelsInnerList;
            }
            catch (Exception ex)
            {
                Sitecore.Diagnostics.Log.Error(ex.ToString(), this);
                return new List<string>();
            }
        }

        private PropertyInfo[] GetModelProps(Type modelTypeInput)
        {

            if (modelTypeInput == null)
            {
                return null;
            }

            PropertyInfo[] modelProps = null;

            try
            {
                modelProps = modelTypeInput.GetProperties();
            }
            catch (Exception ex)
            {
                Sitecore.Diagnostics.Log.Error(ex.ToString(), this);
                return modelProps;
            }
            return modelProps;
        }

        private Type GetModelType(Dictionary<string, string> keyValuePairs)
        {
            if (keyValuePairs != null && keyValuePairs.Count > 0 && keyValuePairs.ContainsKey(ModelsLabel))
            {
                string CoveoMvcModel = keyValuePairs[ModelsLabel];

                var modelTypeReturn = Type.GetType(CoveoMvcModel);

                return modelTypeReturn;
            }

            return null;
        }

        private object GetAndInitializeModel(Type modelTypeInput, Rendering renderingObj)
        {
            if (modelTypeInput == null || renderingObj == null)
            {
                return null;
            }

            object modelObj = null;

            try
            {
                modelObj = Activator.CreateInstance(modelTypeInput);
                if (modelObj != null)
                {
                    var initMethod = modelTypeInput.GetMethod(InitializeMethodName, new[] { typeof(Rendering) });

                    if (initMethod != null)
                    {
                        renderingObj.DataSource = DatasourceHelper.ResolveRenderingDatasource(renderingObj.DataSource);

                        initMethod.Invoke(modelObj, new object[] { (object)renderingObj });
                    }
                }
            }
            catch (Exception ex)
            {
                Sitecore.Diagnostics.Log.Error(ex.ToString(), this);
                return modelObj;
            }

            return modelObj;
        }

        private FieldList AddItemIdAndHiveDatasourceFields(FieldList fields, Item item)
        {
            if (fields == null)
            {
                return new FieldList();
            }

            if (item == null)
            {
                return fields;
            }

            if (item?.Fields[Templates.BaseCoveoUIComponent.Fields.ItemIdFieldName] != null && item.Fields[Templates.BaseCoveoUIComponent.Fields.ItemIdFieldName].HasValue)
            {
                fields.Add(Templates.BaseCoveoHeadlessWithSubmodels.Fields.IdFieldId, item.Fields[Templates.BaseCoveoUIComponent.Fields.ItemIdFieldName].Value);
            }

            fields.Add(Templates.BaseCoveoHeadlessWithSubmodels.Fields.HiveDataSourceFieldId, item?.ID?.ToString() ?? "");

            return fields;
        }
    }
}