﻿using iData.Feature.CoveoHeadless.FieldSerializers;
using Sitecore.Data.Fields;
using Sitecore.Diagnostics;
using Sitecore.LayoutService.Serialization;
using Sitecore.LayoutService.Serialization.FieldSerializers;
using Sitecore.LayoutService.Serialization.Pipelines.GetFieldSerializer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace iData.Feature.CoveoHeadless.Pipelines.GetFieldSerializer
{
    public class GetCustomFieldSerializer : BaseGetFieldSerializer
    {
        public GetCustomFieldSerializer(IFieldRenderer fieldRenderer) : base(fieldRenderer)
        {
        }

        public override bool CanHandleField(Field field)
        {
            if (field == null)
            {
                return false;
            }
            return this.FieldTypes.Any<string>((string f) => f.Equals(field.Type, StringComparison.OrdinalIgnoreCase));
        }

        public override void Process(GetFieldSerializerPipelineArgs args)
        {
            Assert.ArgumentNotNull(args, "args");
            if (!this.CanHandleField(args.Field))
            {
                return;
            }
            this.SetResult(args);
            args.AbortPipeline();
        }

        protected override void SetResult(GetFieldSerializerPipelineArgs args)
        {
            Assert.ArgumentNotNull(args, "args");
            args.Result = new JsonFieldSerializer(this.FieldRenderer);
        }
    }
}