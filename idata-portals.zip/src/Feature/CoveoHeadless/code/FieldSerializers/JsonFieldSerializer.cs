﻿using Newtonsoft.Json;
using Sitecore.Data.Fields;
using Sitecore.Diagnostics;
using Sitecore.LayoutService.Serialization;
using Sitecore.LayoutService.Serialization.FieldSerializers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace iData.Feature.CoveoHeadless.FieldSerializers
{
    public class JsonFieldSerializer : BaseWrapperFieldSerializer
    {
        public JsonFieldSerializer(IFieldRenderer fieldRenderer) : base(fieldRenderer)
        {
        }

        protected virtual void HandleRecursionLimitExceeded(Field field, JsonTextWriter writer)
        {
        }

        public override void Serialize(Field field, JsonTextWriter writer)
        {
            Assert.ArgumentNotNull(field, "field");
            Assert.ArgumentNotNull(writer, "writer");
            string str = string.Format("{0}|{1}|{2}", base.GetType().FullName, field.Item.ID, field.ID);
            using (RecursionLimit recursionLimit = new RecursionLimit(str, 1))
            {
                if (!recursionLimit.Exceeded)
                {
                    if (!string.IsNullOrWhiteSpace(field.Value))
                    {
                        Log.Debug(string.Format("Attempting to load value for field {0}", field.ID), this);
                    }
                    writer.WritePropertyName(field.Name);
                    writer.WriteStartObject();
                    writer.WritePropertyName("value");
                    if (string.IsNullOrWhiteSpace(field.Value))
                    {
                        writer.WriteValue(field.Value);
                    }
                    else
                    {
                        writer.WriteRawValue(field.Value);
                    }

                    writer.WriteEndObject();
                }
                else
                {
                    this.HandleRecursionLimitExceeded(field, writer);
                }
            }
        }
    }
}