﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Coveo.Framework.Databases;
using Coveo.Framework.Items;
using Coveo.UI.Components.Dependencies;
using Coveo.UI.Components.SitecoreProperties;
using Coveo.UI.Components.Helpers;
using Coveo.Framework.Serialization;
using Sitecore.Data;
using RF = iData.Foundation.Sitecore.Pipelines.RenderField;

namespace iData.Feature.CoveoHeadless.UI.PropertyConverters
{
    public class ItemIdToItemMappingAllFieldsPropertyConverter : ISitecorePropertyConverter
    {
        private readonly IDatabaseWrapper DatabaseWrapper;

        private readonly IItemFieldsFetcher ItemFieldsFetcher;

        private readonly IJsonSerializer JsonSerializer;

        public ItemIdToItemMappingAllFieldsPropertyConverter() : this(StaticComponentsServiceFetcher.GetService<IItemFieldsFetcher>(),
            StaticComponentsServiceFetcher.GetService<IDatabaseWrapper>(), StaticComponentsServiceFetcher.GetService<IJsonSerializer>())
        {
        
        }

        public ItemIdToItemMappingAllFieldsPropertyConverter(IItemFieldsFetcher ItemFieldsFetcher, IDatabaseWrapper DatabaseWrapper, IJsonSerializer JsonSerializer)
        {
            this.DatabaseWrapper = DatabaseWrapper;
            this.ItemFieldsFetcher = ItemFieldsFetcher;
            this.JsonSerializer = JsonSerializer;
        }

        public dynamic Convert(string itemId)
        {
            string resultSerilized = null;

            if (!string.IsNullOrEmpty(itemId))
            {
                Dictionary<string, string> outerList = new Dictionary<string, string>();

                outerList.Add("id", this.DatabaseWrapper.GetItem(itemId).ID.ToString());

                IDictionary<string, string> listItemValues = this.GetListItemValue(itemId);

                IDictionary<string, string> updatedList = new Dictionary<string, string>();

                foreach (var itemField in listItemValues)
                {
                    if (ID.IsID(itemField.Value))
                    {
                        var innerValue = new Dictionary<string, string>();

                        innerValue.Add("id", ID.Parse(itemField.Value).ToString());

                        var listOfSubfields = GetListItemValue(itemField.Value);

                        foreach (var subfield in listOfSubfields)
                        {
                            innerValue.Add(subfield.Key, subfield.Value);
                        }

                        var serizlizedSubfield = SerializeToJson(innerValue);

                        updatedList.Add(itemField.Key, serizlizedSubfield);
                    }
                    else
                    {
                        if (itemField.Value.StartsWith("<image mediaid="))
                        {
                            var id = itemField.Value.Substring(15).TrimEnd('>').TrimEnd('/').TrimEnd(' ').Replace("\"", string.Empty);

                            if (ID.IsID(id))
                            {
                                var imageItemFields = GetListItemValue(id);

                                if (imageItemFields.ContainsKey("Mime Type") && imageItemFields["Mime Type"].Equals("image/svg+xml"))
                                {
                                    var renderer = new RF.CustomImageRenderer();

                                    var imageItem = this.DatabaseWrapper.GetItem(id);
                                    var mediaItem = imageItem.GetMediaItem();
                                    var mediaStream = mediaItem.GetMediaStream();

                                    var svg = renderer.RenderSvgImage(mediaStream);
                                    
                                    updatedList.Add("svgCode", svg);
                                }
                            }
                        }
                        else
                        {
                            updatedList.Add(itemField.Key, itemField.Value);
                        }
                    }
                }
                
                var serialized = SerializeToJson(updatedList);

                outerList.Add("fields", serialized);

                resultSerilized = SerializeToJson(outerList);
            }
            return (object)resultSerilized;
        }

        private IDictionary<string, string> GetListItemValue(string p_ItemId)
        {
            IDictionary<string, string> allFields = null;

            IItem item = this.DatabaseWrapper.GetItem(p_ItemId);
            if (item != null)
            {
                allFields = this.ItemFieldsFetcher.GetAllFields(p_ItemId);
            }
            return allFields;
        }

        private string SerializeToJson(IDictionary<string, string> p_Values)
        {
            if (!p_Values.Keys.Any<string>())
            {
                return "";
            }
            
            return this.JsonSerializer.Serialize(p_Values);
        }

        private dynamic GetDefaultValue()
        {
            return default;
        }
    }
}