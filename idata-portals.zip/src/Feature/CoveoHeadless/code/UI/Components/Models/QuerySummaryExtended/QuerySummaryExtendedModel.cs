﻿using Coveo.UI.Components.Models.Components;
using iData.Feature.CoveoHeadless.UI.Components.ModelProperties.QuerySummaryExtended;

namespace iData.Feature.CoveoHeadless.UI.Components.Models.QuerySummaryExtended
{
    public class QuerySummaryExtendedModel : QuerySummaryModel<QuerySummaryExtendedProperties>
    {
        public QuerySummaryExtendedModel()
        {
        }
    }
}