﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore.Mvc.Presentation;
using Coveo.UI.Components.Models.ResultsList;
using iData.Feature.CoveoHeadless.UI.Components.ModelProperties.ResultsListExtended;
using Coveo.UI.Components.RenderingContext;

namespace iData.Feature.CoveoHeadless.UI.Components.Models.ResultsListExtended
{
    public class ResultsListExtendedModel : ResultsListModel<ResultsListExtendedProperties>
    {
        private const string COMPONENT_NAME = "Coveo Results List Extended";
        private Rendering rendering;

        public ResultsListExtendedModel() : base()
        {
        
        }

        public new void Initialize(Rendering rendering)
        {
            base.Initialize(rendering);
            this.rendering = rendering;
        }

        public override void OnRenderingContextInitialization(IRenderingContext p_RenderingContext)
        {
            base.OnRenderingContextInitialization(p_RenderingContext);
        }

        public new string VisibleText
        {
            get
            {
                if (string.IsNullOrEmpty(base.Properties.Layout))
                {
                    return "Coveo Results List Extended";
                }
                return string.Format("{0} (Layout: {1})", "Coveo Results List Extended", base.Properties.Layout);
            }
        }
    }
}