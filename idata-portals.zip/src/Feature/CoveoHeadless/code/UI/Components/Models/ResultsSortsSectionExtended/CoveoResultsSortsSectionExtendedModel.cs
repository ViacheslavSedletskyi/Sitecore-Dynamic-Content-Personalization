﻿using Coveo.UI.Components.Models.Sections;
using iData.Feature.CoveoHeadless.UI.Components.ModelProperties.ResultsSortsSectionExtended;

namespace iData.Feature.CoveoHeadless.UI.Components.Models.ResultsSortsSectionExtended
{
    public class CoveoResultsSortsSectionExtendedModel : ResultsSortsSectionModel<ResultsSortsSectionExtendedProperties>
    {
        public CoveoResultsSortsSectionExtendedModel()
        {
        }
    }
}