﻿using Coveo.UI.Components.Models.Resources;
using Coveo.UI.Components.Models;
using Sitecore.Mvc.Presentation;
using iData.Feature.CoveoHeadless.UI.Components.ModelProperties.Resources;
using System.Linq;

namespace iData.Feature.CoveoHeadless.UI.Components.Models.Resources
{
    public class CustomizedSearchResourcesModel : SearchResourcesModel<CustomizedSearchResourcesProperties>, IModelWithProperties<CustomizedSearchResourcesProperties>, IModelWithRawProperties, IBaseComponentModel, IBaseComponentProperties, IRenderingModel, IComponentModel
	{
        public CustomizedSearchResourcesModel() : base()
        {
        
        }

        protected override void OnPropertiesInitialized()
        {
            base.OnPropertiesInitialized();

            MergeRawPropertiesExternalFields();
        }

        private void MergeRawPropertiesExternalFields()
        {
            string customPrefix = "idata-";
            string coveoForSitecoreAttributePrefix = "sc-";

            var customAttributeKey = this.RawProperties.Keys.FirstOrDefault(attr => attr.StartsWith(customPrefix));
            if (!string.IsNullOrWhiteSpace(customAttributeKey))
            {
                var valueToMerge = this.RawProperties[customAttributeKey];
                var originalKey = coveoForSitecoreAttributePrefix + customAttributeKey.Substring(customPrefix.Length);
                var originalValue = this.RawProperties[originalKey];

                this.RawProperties.Remove(originalKey);
                this.RawProperties.Remove(customAttributeKey);

                this.RawProperties.Add(originalKey, string.Join(", ", originalValue.TrimEnd(']'), valueToMerge.TrimStart('[')));
            }
        }
    }
}