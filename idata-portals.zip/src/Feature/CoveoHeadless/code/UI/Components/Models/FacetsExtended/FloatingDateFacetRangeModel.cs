﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Coveo.UI.Components.Models.Facets;
using Coveo.UI.Components.Models;
using Sitecore.Mvc.Presentation;
using System.Runtime.CompilerServices;
using iData.Feature.CoveoHeadless.UI.Components.ModelProperties.FacetsExtended;


namespace iData.Feature.CoveoHeadless.UI.Components.Models.FacetsExtended
{
    public class FloatingDateFacetRangeModel : FacetModel<FloatingFacetProperties>, IFacetModel<FloatingFacetProperties>, IModelWithProperties<FloatingFacetProperties>, IModelWithRawProperties, IBaseComponentModel, IBaseComponentProperties, IRenderingModel, IComponentModel
    {
        public FloatingDateFacetRangeModel()
        {
            
        }
    }
}