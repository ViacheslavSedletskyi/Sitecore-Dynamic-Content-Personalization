﻿using Coveo.UI.Components.SearchUiProperties;
using Coveo.UI.Components.SitecoreProperties;
using Coveo.UI.Components.ModelProperties.ResultsList;
using iData.Feature.CoveoHeadless.UI.PropertyConverters;

namespace iData.Feature.CoveoHeadless.UI.Components.ModelProperties.ResultsListExtended
{
    public class ResultsListExtendedProperties : ResultsListProperties
    {
        public ResultsListExtendedProperties()
        {
        
        }

        [SearchUiProperty]
        [SitecoreProperty("ExploreDatasetButton", PropertyConverter = typeof(ItemIdToItemMappingAllFieldsPropertyConverter))]
        public string ExploreDatasetButton { get; set; }

        [SearchUiProperty]
        [SitecoreProperty("MetadataButton", PropertyConverter = typeof(ItemIdToItemMappingAllFieldsPropertyConverter))]
        public string MetadataButton { get; set; }

        [SearchUiProperty]
        [SitecoreProperty("DownloadButton", PropertyConverter = typeof(ItemIdToItemMappingAllFieldsPropertyConverter))]
        public string DownloadButton { get; set; }

        [SearchUiProperty]
        [SitecoreProperty("ChartPreviewButton", PropertyConverter = typeof(ItemIdToItemMappingAllFieldsPropertyConverter))]
        public string ChartPreviewButton { get; set; }

        [SearchUiProperty]
        [SitecoreProperty("AddToWatchlistButton", PropertyConverter = typeof(ItemIdToItemMappingAllFieldsPropertyConverter))]
        public string AddToWatchlistButton { get; set; }

        [SearchUiProperty]
        [SitecoreProperty("DownloadTimeseriaButton", PropertyConverter = typeof(ItemIdToItemMappingAllFieldsPropertyConverter))]
        public string DownloadTimeseriaButton { get; set; }

        [SearchUiProperty]
        [SitecoreProperty("MetadataTimeseriaButton", PropertyConverter = typeof(ItemIdToItemMappingAllFieldsPropertyConverter))]
        public string MetadataTimeseriaButton { get; set; }

        [SearchUiProperty]
        [SitecoreProperty("SubscribeToDatasetButton", PropertyConverter = typeof(ItemIdToItemMappingAllFieldsPropertyConverter))]
        public string SubscribeToDatasetButton { get; set; }

        [SearchUiProperty]
        [SitecoreProperty("SeeVintagesOfDatasetButton", PropertyConverter = typeof(ItemIdToItemMappingAllFieldsPropertyConverter))]
        public string SeeVintagesOfDatasetButton { get; set; }
		
		[SearchUiProperty]
        [SitecoreProperty("DownloadDatasetVintagesButton", PropertyConverter = typeof(ItemIdToItemMappingAllFieldsPropertyConverter))]
        public string DownloadDatasetVintagesButton { get; set; }

        [SearchUiProperty]
        [SitecoreProperty("DatasetVintageHighlightsButton", PropertyConverter = typeof(ItemIdToItemMappingAllFieldsPropertyConverter))]
        public string DatasetVintageHighlightsButton { get; set; }

        [SearchUiProperty]
        [SitecoreProperty("HideTimeseriesLabel")]
        public string HideTimeseriesLabel { get; set; }

        [SearchUiProperty]
        [SitecoreProperty("ShowTimeseriesLabel")]
        public string ShowTimeseriesLabel { get; set; }

        [SearchUiProperty]
        [SitecoreProperty("ShowMoreLabel")]
        public string ShowMoreLabel { get; set; }

        [SearchUiProperty]
        [SitecoreProperty("HideAllLabel")]
        public string HideAllLabel { get; set; }

        [SearchUiProperty]
        [SitecoreProperty("ShowHighlights")]
        public string ShowHighlights { get; set; }
    }
}