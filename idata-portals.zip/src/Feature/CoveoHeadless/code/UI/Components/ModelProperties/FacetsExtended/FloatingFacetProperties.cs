﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Coveo.UI.Components.ModelProperties;
using Coveo.UI.Components.Models;
using Coveo.UI.Components.SearchUiProperties;
using Coveo.UI.Components.SitecoreProperties;
using System.Runtime.CompilerServices;
using Coveo.UI.Components.ModelProperties.Facets;
using Coveo.UI.Components.SearchUiProperties.PropertySerializer;
using Coveo.UI.Components.Helpers;
using Coveo.Framework.ServiceLocator;
using Coveo.Framework.Items;
using iData.Feature.CoveoHeadless.UI.Components.Helpers;

namespace iData.Feature.CoveoHeadless.UI.Components.ModelProperties.FacetsExtended
{
    public class FloatingFacetProperties : FacetProperties, IModelProperties, IReadableModel, IWritableModel, IDependentModelProperties
    {
        public FloatingFacetProperties()
        {
            
        }

        [SearchUiProperty(PropertySerializer = typeof(RangesPropertySerializer))]
        public new IEnumerable<CustomRangeValue> Ranges
        {
            get;
            private set;
        }

        public new void SetDependentProperties(IServiceFetcher ServiceFetcher)
        {
            bool? isDate = this.IsDate;
            this.Ranges = (isDate.GetValueOrDefault() & isDate.HasValue ?
                CustomRangeResolverExtended.GetCustomDateRangeValues(this.CustomRangeItems, this.DateFormat ?? "yyyy/MM/dd") :
                CustomRangeResolverExtended.GetCustomNumericRangeValues(this.CustomRangeItems));
        }

    }
}