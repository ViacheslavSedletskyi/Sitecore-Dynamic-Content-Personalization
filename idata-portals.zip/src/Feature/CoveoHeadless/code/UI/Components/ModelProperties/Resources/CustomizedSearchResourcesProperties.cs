﻿using Coveo.Framework.Configuration;
using Coveo.UI.Components.ModelProperties.Resources;
using Coveo.UI.Components.SearchUiProperties;
using Coveo.UI.Components.SearchUiProperties.PropertySerializer;
using iData.Foundation.Platform;
using iData.Foundation.Platform.Models;
using Sitecore.Data;
using Sitecore.Data.Items;
using System.Collections.Generic;
using System.Linq;
using iData.Foundation.Sitecore.Extensions;
using Newtonsoft.Json;
using System;
using Coveo.UI.Components.Models;
using Coveo.UI.Components.SitecoreProperties;
using Coveo.UI.Components.ModelProperties;

namespace iData.Feature.CoveoHeadless.UI.Components.ModelProperties.Resources
{
    using Constants = iData.Foundation.Platform.Constants;

    public class CustomizedSearchResourcesProperties : SearchResourcesProperties, IModelProperties, IReadableModel, IWritableModel, IContextualModelProperties, IDependentModelProperties
    {
        public CustomizedSearchResourcesProperties() : base()
        {
            
        }

        [SearchUiProperty(PropertyKey = "metadata-fields-configruation", Prefix = true)]
        public virtual string IData_MetadataFieldsConfiguration { get { return GetMetadataFieldsConfiguration(); } private set { } }


        [SearchUiProperty(PropertyKey = "idata-external-fields", Prefix = false, PropertySerializer = typeof(ExternalFieldConfigurationArraySerializer))]
        public virtual IEnumerable<ExternalFieldConfiguration> IData_ExternalFields { get { return GetPortalDynamicFields();  } private set { } }

        private static IEnumerable<ExternalFieldConfiguration> GetPortalDynamicFields()
        {
            var metadataFields = Sitecore.Context.Database.SelectItems($"/sitecore/Catalog/*[@@templateid = '{Templates.MetadataFieldsRootFolder.ID}']//*[@@templateid = '{Templates.MetadataField.ID}' and @IsComputedField != '1']");

            foreach (var metadataField in metadataFields)
            {
                var coveoMetadataFieldName = metadataField[Templates._MetadataSearchFieldDefinition.Fields.SearchFieldName];

                if (!string.IsNullOrWhiteSpace(coveoMetadataFieldName))
                {
                    yield return new ExternalFieldConfiguration() { FieldName = coveoMetadataFieldName, FieldTypeName = "string", ShouldEscape = false };
                }
            }
        }

        private static string GetMetadataFieldsConfiguration()
        {
            var metadataConfigurationRootItem = Sitecore.Context.Database.SelectItems($"{Constants.MetadataConfigurationBasePath}/*[@@templateid = '{Constants.MetadataConfigurationRootFolderId}']")?.FirstOrDefault();

            if (metadataConfigurationRootItem != null && metadataConfigurationRootItem.HasChildren)
            {
                try
                {
                    var objectBuildOutput = metadataConfigurationRootItem.Children.Select(BuildMetadataEntryObject);

                    return JsonConvert.SerializeObject(objectBuildOutput, new JsonSerializerSettings() { NullValueHandling = NullValueHandling.Ignore });
                }
                catch
                {
                    return null;
                }
            }

            return string.Empty;
        }

        private static MetadataEntitySettings BuildMetadataEntryObject(Item metadataEntryItem)
        {
            if (metadataEntryItem.InheritsFrom(Templates._MetadataSettingsObject.ID))
            {
                var complexEntityObject = CreateMetadataEntryObject(metadataEntryItem);

                if (complexEntityObject != null) 
                {
                    var complexEntityObjectDependencies = metadataEntryItem.Axes.GetDescendants().Select(CreateMetadataEntryObject);
                    if (complexEntityObjectDependencies.Any())
                    {
                        complexEntityObject.Dependencies = complexEntityObjectDependencies;
                    }
                }

                return complexEntityObject;
            }

            if (metadataEntryItem.HasChildren && metadataEntryItem.Children.Any(c => c.InheritsFrom(Templates._MetadataSettingsObject.ID)))
            {
                var complexEntityObject = CreateMetadataEntryObject(metadataEntryItem);

                if (complexEntityObject != null) 
                {
                    complexEntityObject.Dependencies = metadataEntryItem.Children.Select(BuildMetadataEntryObject);
                }

                return complexEntityObject;
            }

            return CreateMetadataEntryObject(metadataEntryItem);
        }

        private static MetadataEntitySettings CreateMetadataEntryObject(Item metadataEntryItem)
        {
            IEnumerable<MetadataFieldDescription> GetMetadataFieldDescription(string rawFieldValue)
            {
                var nameValueCollection = ItemExtensions.ParseLookupNameLookupValueField(rawFieldValue);

                foreach (var mvcKey in nameValueCollection.AllKeys)
                {
                    yield return CreateMetadataFieldDescription(mvcKey, nameValueCollection[mvcKey]);
                }
            }

            MetadataFieldDescription CreateMetadataFieldDescription(string metadataFieldItemId, string metadataFieldTypeItemId)
            {
                var metadataFieldInfo = global::Sitecore.Context.Database.GetItem(metadataFieldItemId);
                var metadataFieldType = global::Sitecore.Context.Database.GetItem(metadataFieldTypeItemId);

                return new MetadataFieldDescription()
                {
                    AppearanceType = Convert.ToByte(metadataFieldType[Templates.MetadataFieldType.Fields.CodeType]),
                    Name = metadataFieldInfo[Templates._MetadataSearchFieldDefinition.Fields.SearchFieldName],
                    Title = metadataFieldInfo[Templates._MetadataSearchFieldDefinition.Fields.Title]
                };
            }

            string GetIdentifierValue(string fieldValue)
            {
                if (ID.IsID(fieldValue))
                {
                    var identifierItem = global::Sitecore.Context.Database.GetItem(fieldValue);

                    return identifierItem != null && identifierItem.InheritsFrom(Templates.IMetadataObject.ID)
                        ? identifierItem[Templates.Dataset.Fields.ExternalId]
                        : identifierItem?.Name;
                }

                return fieldValue;
            }

            if (string.IsNullOrWhiteSpace(metadataEntryItem[Templates._MetadataSettings.Fields.CardMetadataFields]) &&
                string.IsNullOrWhiteSpace(metadataEntryItem[Templates._MetadataSettings.Fields.MetadataSidebarFields])) 
            { return null; }

            return new MetadataEntitySettings()
            {
                Identifier = GetIdentifierValue(metadataEntryItem[Constants.MetadataObjectIdentifierFieldName]),
                CardFields = GetMetadataFieldDescription(metadataEntryItem[Templates._MetadataSettings.Fields.CardMetadataFields]),
                SidebarFields = GetMetadataFieldDescription(metadataEntryItem[Templates._MetadataSettings.Fields.MetadataSidebarFields]),
            };
        }
    }
}