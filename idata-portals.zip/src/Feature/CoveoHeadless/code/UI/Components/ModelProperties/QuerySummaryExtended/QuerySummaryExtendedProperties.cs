﻿using Coveo.UI.Components.ModelProperties.Components;
using Coveo.UI.Components.SearchUiProperties;
using Coveo.UI.Components.SitecoreProperties;

namespace iData.Feature.CoveoHeadless.UI.Components.ModelProperties.QuerySummaryExtended
{
    public class QuerySummaryExtendedProperties : QuerySummaryProperties
    {
        [SearchUiProperty]
        [SitecoreProperty("Text Block Enabled")]
        public string TextBlockEnabled
        {
            get;
            set;
        }

        [SearchUiProperty]
        [SitecoreProperty("Text Block Title")]
        public string TextBlockTitle
        {
            get;
            set;
        }

        [SearchUiProperty]
        [SitecoreProperty("Text Block Content")]
        public string TextBlockContent
        {
            get;
            set;
        }
    }
}