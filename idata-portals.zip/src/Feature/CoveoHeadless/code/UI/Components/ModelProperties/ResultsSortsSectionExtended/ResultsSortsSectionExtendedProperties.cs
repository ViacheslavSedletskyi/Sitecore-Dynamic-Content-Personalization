﻿using Coveo.UI.Components.ModelProperties.Sections;
using Coveo.UI.Components.SearchUiProperties;
using Coveo.UI.Components.SitecoreProperties;

namespace iData.Feature.CoveoHeadless.UI.Components.ModelProperties.ResultsSortsSectionExtended
{
    public class ResultsSortsSectionExtendedProperties : ResultsSortsSectionProperties
    {
        public ResultsSortsSectionExtendedProperties()
        {
        }

        [SearchUiProperty]
        [SitecoreProperty("Title")]
        public string Title
        {
            get;
            set;
        }

        [SearchUiProperty]
        [SitecoreProperty("Tooltip")]
        public string Tooltip
        {
            get;
            set;
        }
    }
}