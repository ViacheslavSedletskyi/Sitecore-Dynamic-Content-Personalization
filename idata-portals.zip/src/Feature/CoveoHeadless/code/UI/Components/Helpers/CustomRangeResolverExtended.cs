﻿using Coveo.UI.Components.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Coveo.Framework.Collections;
using Coveo.Framework.Items;
using Coveo.UI.Components.ModelProperties.Facets;
using Sitecore;
using Coveo.Framework.Utils;

namespace iData.Feature.CoveoHeadless.UI.Components.Helpers
{
    public static class CustomRangeResolverExtended
    {
        static CustomRangeResolverExtended()
        {

        }

        public static IEnumerable<CustomRangeValue> GetCustomDateRangeValues(IEnumerable<IItem> p_Items, string p_DateFormat)
        {
            return EnumerableExtensions.SelectOrDefault<IItem, CustomRangeValue>(p_Items, (IItem item) => new CustomRangeValue()
            {
                Start = FormatDate(GetDates(item).startDate),
                End = FormatDate(GetDates(item).endDate),
                EndInclusive = GetEndInclusiveFieldValue(item),
                Label = GetDateLabel(item, p_DateFormat)
            });
        }

        private static string FormatDate(string Date)
        {
            return DateUtil.IsoDateToDateTime(Date).ToSearchUiFormat();
        }

        private static string FormatDate(DateTime Date)
        {
            return Date.ToSearchUiFormat();
        }

        private static string GetStartFieldValue(IItem p_Item)
        {
            return p_Item.GetFieldValue(Constant.DateRange.RangeStartFieldName);
        }

        private static (DateTime startDate, DateTime endDate) GetDates(IItem p_Item)
        {
            DateTime startDate = new DateTime();
            DateTime endDate = new DateTime();

            bool subtract = false;

            if (!string.IsNullOrWhiteSpace(p_Item.GetFieldValue(Constant.DateRange.RangeEndFieldName)) &&
                !string.IsNullOrWhiteSpace(p_Item.GetFieldValue(Constant.DateRange.RangeStartFieldName))
                )
            {
                endDate = DateUtil.IsoDateToDateTime(p_Item.GetFieldValue(Constant.DateRange.RangeEndFieldName));
                startDate = DateUtil.IsoDateToDateTime(p_Item.GetFieldValue(Constant.DateRange.RangeStartFieldName));

                return (startDate, endDate);
            }
            
            if (p_Item.TemplateName.Equals(Constant.FloatingDateRange.FloatingTillDateRangeFieldName))
            {
                subtract = true;

                var endParsed = p_Item.GetFieldValue(Constant.FloatingDateRange.EndDateIsNowFieldName) != null;

                if (!endParsed)
                {
                    endDate = DateUtil.IsoDateToDateTime(p_Item.GetFieldValue(Constant.DateRange.RangeEndFieldName));
                }
                else
                {
                    bool endIsNow = p_Item.GetFieldValue(Constant.FloatingDateRange.EndDateIsNowFieldName)
                        .Equals("1") ? true : false;

                    if (endIsNow)
                    {
                        endDate = DateTime.UtcNow;
                    }
                    else
                    {
                        endDate = DateUtil.IsoDateToDateTime
                            (p_Item.GetFieldValue(Constant.FloatingDateRange.EndDateIfNotNowFieldName));
                    }
                }

                startDate = GetDateByPeriod(p_Item, endDate, subtract);

                return (startDate, endDate);
            }

            var startParsed = p_Item.GetFieldValue(Constant.FloatingDateRange.StartDateIsNowFieldName) != null;

            if (!startParsed)
            {
                startDate = DateUtil.IsoDateToDateTime(p_Item.GetFieldValue(Constant.DateRange.RangeStartFieldName));
            }
            else
            {
                bool startIsNow = p_Item.GetFieldValue(Constant.FloatingDateRange.StartDateIsNowFieldName)
                    .Equals("1") ? true : false;

                if (startIsNow)
                {
                    startDate = DateTime.UtcNow;
                }
                else
                {
                    startDate = DateUtil.IsoDateToDateTime(
                        p_Item.GetFieldValue(Constant.FloatingDateRange.StartDateIfNotNowFieldName));
                }
            }

            endDate = GetDateByPeriod(p_Item, startDate, subtract);

            return (startDate, endDate);
        }

        private static DateTime GetDateByPeriod(IItem item, DateTime initialDate, bool subtract)
        {
            var periodType = item.GetFieldValue(Constant.FloatingDateRange.TypeOfPeriodFieldName);
            var numberOfPeriods = item.GetFieldValue(Constant.FloatingDateRange.NumberOfPeriodsFieldName);

            var numberParsed = Int32.TryParse(numberOfPeriods, out int numberOfPeriodsParsed);

            var resultDate = new DateTime();

            if (!string.IsNullOrWhiteSpace(periodType) || numberParsed)
            {
                switch (periodType)
                {
                    case "Days":
                        {
                            resultDate = subtract ? 
                                initialDate.SubtractDays(numberOfPeriodsParsed) : 
                                initialDate.AddDays(numberOfPeriodsParsed);
                            break;
                        }
                    case "Weeks":
                        {
                            resultDate = subtract ?
                                initialDate.SubtractDays(7 * numberOfPeriodsParsed) :
                                initialDate.AddDays(7 * numberOfPeriodsParsed);
                            break;
                        }
                    case "Months":
                        {
                            resultDate = subtract ?
                                initialDate.AddMonths(-numberOfPeriodsParsed) :
                                initialDate.AddMonths(numberOfPeriodsParsed);
                            break;
                        }
                    case "Quarters":
                        {
                            resultDate = subtract ?
                                initialDate.AddMonths(-3 * numberOfPeriodsParsed) :
                                initialDate.AddMonths(3 * numberOfPeriodsParsed);
                            break;
                        }
                    case "Years":
                        {
                            resultDate = subtract ?
                                initialDate.AddYears(-numberOfPeriodsParsed) :
                                initialDate.AddYears(numberOfPeriodsParsed);
                            break;
                        }
                    default:
                        break;
                }
            }
            return resultDate;
        }

        private static string GetEndFieldValue(IItem p_Item)
        {
            return p_Item.GetFieldValue(Constant.DateRange.RangeEndFieldName);
        }

        private static bool GetEndInclusiveFieldValue(IItem p_Item)
        {
            return p_Item.GetFieldValue(Constant.DateRange.RangeEndInclusiveFieldName) == "1";
        }

        private static string GetLabelFieldValue(IItem p_Item)
        {
            return p_Item.GetFieldValue(Constant.DateRange.RangeLabelFieldName);
        }

        private static string GetDateLabel(IItem p_Item, string p_DateFormat)
        {
            string labelFieldValue = GetLabelFieldValue(p_Item);
            if (string.IsNullOrEmpty(labelFieldValue))
            {
                DateTime dateTime = GetDates(p_Item).startDate;
                DateTime dateTime1 = GetDates(p_Item).endDate;
                labelFieldValue = FormatLabel(dateTime.ToString(p_DateFormat), dateTime1.ToString(p_DateFormat));
            }
            return labelFieldValue;
        }

        private static string FormatLabel(string p_StartValue, string p_EndValue)
        {
            return string.Format("{0} - {1}", p_StartValue, p_EndValue);
        }


        public static IEnumerable<CustomRangeValue> GetCustomNumericRangeValues(IEnumerable<IItem> p_Items)
        {
            return EnumerableExtensions.SelectOrDefault<IItem, CustomRangeValue>(p_Items, (IItem item) => new CustomRangeValue()
            {
                Start = GetStartFieldValue(item),
                End = GetEndFieldValue(item),
                EndInclusive = GetEndInclusiveFieldValue(item),
                Label = GetNumericLabel(item)
            });
        }

        private static string GetNumericLabel(IItem p_Item)
        {
            string labelFieldValue = GetLabelFieldValue(p_Item);
            if (string.IsNullOrEmpty(labelFieldValue))
            {
                labelFieldValue = FormatLabel(GetStartFieldValue(p_Item), GetEndFieldValue(p_Item));
            }
            return labelFieldValue;
        }
    }
}