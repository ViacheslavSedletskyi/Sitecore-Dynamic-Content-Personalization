﻿using Sitecore.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace iData.Feature.CoveoHeadless.Constants
{
    public struct Templates
    {
        public struct BaseCoveoHeadless
        {

            public struct Fields
            {
                public const string CssClassFieldName = "cssClass";
                public const string HiveDataSourceFieldName = "hiveDataSource";
                public const string IdFieldName = "id";
                public const string RawPropertiesFieldName = "rawProperties";
                public const string PropertiesFieldName = "properties";
            }
        }

        public struct CoveoParametersTemplate
        {
            public struct Fields
            {
                public const string CssClassFieldName = "cssClass";
            }
        }

        public struct BaseCoveoUIComponent 
        {
            public struct Fields
            {
                public const string ItemIdFieldName = "ItemId";
                public static readonly ID ItemIdFieldId = new ID("{D48AD7E5-FD34-4EC2-B753-4E1867B05714}");
            }
        }

        public struct BaseCoveoHeadlessWithSubmodels
        {
            public struct Fields
            {
                public const string CssClassFieldName = "cssClass";
                public const string HiveDataSourceFieldName = "hiveDataSource";
                public const string IdFieldName = "id";
                public const string RawPropertiesFieldName = "rawProperties";
                public const string PropertiesFieldName = "properties";
                public const string SubModelsFieldName = "subModels";
                public const string HasFilterFieldName = "hasFilter";
                public const string VisibleTextFieldName = "visibleText";


                public static readonly ID CssClassFieldId = new ID("{6B2FBBB9-DE43-49B0-A82B-3F5E86B27419}");
                public static readonly ID HiveDataSourceFieldId = new ID("{A24490FE-536B-49B5-AC23-70551330A5E9}");
                public static readonly ID IdFieldId = new ID("{7CF8070F-C16C-47AC-BB38-223B223CF86E}");
                public static readonly ID RawPropertiesFieldId = new ID("{865E226B-4E06-4DC4-BE48-B37A46C55BF2}");
                public static readonly ID PropertiesFieldId = new ID("{18CCA928-8B62-436C-AF29-253F5390C3F2}");
                public static readonly ID SubModelsFieldId = new ID("{BC9BA5B2-49DF-4D9F-9831-5713007B5C9D}");
                public static readonly ID HasFilterFieldId = new ID("{4BAF4E5B-77D1-454F-81F4-3E923620C714}");
                public static readonly ID VisibleTextFieldId = new ID("{2AD7004B-3DCF-48BD-8305-0C356A14E318}");
                public static readonly ID SearchPageUriFieldId = new ID("{D87213FF-AC0F-4F53-B54A-B46B46B103D0}");
            }

            public struct TemplateId 
            {
                public const string TemplateIdString = "{EB4BFBEC-9043-4DF9-B318-CD323151C852}";
            }
        }
    }
}