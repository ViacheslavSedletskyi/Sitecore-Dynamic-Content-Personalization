﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace iData.Feature.CoveoHeadless
{
    public static class Constant
    {
        public static class DateRange
        {
            public const string RangeStartFieldName = "RangeStart";
            public const string RangeEndFieldName = "RangeEnd";
            public const string RangeEndInclusiveFieldName = "RangeEndInclusive";
            public const string RangeLabelFieldName = "RangeLabel";
        }

        public static class FloatingDateRange
        {
            public const string EndDateIsNowFieldName = "End Date is now";
            public const string EndDateIfNotNowFieldName = "End Date if not now";
            public const string TypeOfPeriodFieldName = "Type of period";
            public const string NumberOfPeriodsFieldName = "Number of periods";
            public const string FloatingTillDateRangeFieldName = "FloatingTillDateRange";
            public const string StartDateIsNowFieldName = "Start Date is now";
            public const string StartDateIfNotNowFieldName = "Start Date if not now";
        }
    }
}