﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;

using Sitecore.Xml;

namespace iData.Feature.CoveoHeadless.Coveo.Jss
{
    public class CoveoJssRenderings
    {
        private readonly Dictionary<string, CoveoJssRenderingDefinition> m_Renderings;

        public CoveoJssRenderings()
        {
            this.m_Renderings = new Dictionary<string, CoveoJssRenderingDefinition>();
        }

        public void AddRendering(XmlNode renderingNode)
        {
            object array;
            string str;

            if (renderingNode != null)
            {
                //Precondition.NotNull(renderingNode, () => Expression.Lambda<Func<object>>(Expression.Field(Expression.Constant(this, typeof(CoveoJssRenderings.<> c__DisplayClass3_0)), FieldInfo.GetFieldFromHandle(typeof(CoveoJssRenderings.<> c__DisplayClass3_0).GetField("renderingNode").FieldHandle)), Array.Empty<ParameterExpression>()));
                string identifier = this.GetIdentifier(renderingNode, out str);
                string attribute = XmlUtil.GetAttribute(CoveoJssRenderings.Attributes.ModelType, renderingNode, true);
                if (string.IsNullOrEmpty(attribute))
                {
                    throw new InvalidOperationException("Ensure your rendering has the `modelType` attribute.");
                }
                Type type = this.CreateAndValidateType(str, identifier, attribute);
                string attribute1 = XmlUtil.GetAttribute(CoveoJssRenderings.Attributes.ExcludedFields, renderingNode, true) ?? "";
                Dictionary<string, CoveoJssRenderingDefinition> mRenderings = this.m_Renderings;
                string str1 = identifier;
                CoveoJssRenderingDefinition coveoJssRenderingDefinition = new CoveoJssRenderingDefinition()
                {
                    ModelType = type,
                    ExcludedFields = attribute1.Split(new char[] { ',' })
                };
                CoveoJssRenderingDefinition coveoJssRenderingDefinition1 = coveoJssRenderingDefinition;
                IEnumerable<XmlNode> childElements = XmlUtil.GetChildElements(CoveoJssRenderings.Attributes.SubModel, renderingNode);
                if (childElements != null)
                {
                    array = (
                        from node in childElements
                        select this.ParseSubModel(str, identifier, node)).ToArray<RenderingSubModelDefinition>();
                }
                else
                {
                    array = null;
                }
                if (array == null)
                {
                    array = new RenderingSubModelDefinition[0];
                }
                coveoJssRenderingDefinition1.SubModels = (RenderingSubModelDefinition[])array;
                mRenderings.Add(str1, coveoJssRenderingDefinition);
            }
        }

        private Type CreateAndValidateType(string identifiedProperty, string idenditifer, string type)
        {
            Type type1 = Type.GetType(type);
            if (type1 == null)
            {
                throw new InvalidOperationException(string.Concat(new string[] { "The rendering does not have a valid type. ", identifiedProperty, ": \"", idenditifer, "\", modelType: \"", type, "\". Ensure that the referenced type exists." }));
            }
            return type1;
        }

        private string GetIdentifier(XmlNode renderingNode, out string identifierProperty)
        {
            string attribute = XmlUtil.GetAttribute(CoveoJssRenderings.Attributes.Name, renderingNode, true);
            if (!string.IsNullOrEmpty(attribute))
            {
                identifierProperty = CoveoJssRenderings.Attributes.Name;
                return attribute;
            }
            string str = XmlUtil.GetAttribute(CoveoJssRenderings.Attributes.ID, renderingNode, true);
            if (string.IsNullOrEmpty(str))
            {
                throw new InvalidOperationException("Ensure your rendering mapping has the `name` or `id` attribute.");
            }
            identifierProperty = CoveoJssRenderings.Attributes.ID;
            return str;
        }

        public CoveoJssRenderingDefinition GetRenderingDefinition(string renderingIdentifier)
        {
            if (!string.IsNullOrWhiteSpace(renderingIdentifier))
            {
                //Precondition.NotEmpty(renderingIdentifier, () => Expression.Lambda<Func<object>>(Expression.Field(Expression.Constant(this, typeof(CoveoJssRenderings.<> c__DisplayClass6_0)), FieldInfo.GetFieldFromHandle(typeof(CoveoJssRenderings.<> c__DisplayClass6_0).GetField("renderingIdentifier").FieldHandle)), Array.Empty<ParameterExpression>()));
                if (!this.m_Renderings.ContainsKey(renderingIdentifier))
                {
                    throw new InvalidOperationException(string.Concat("The rendering with name or id \"", renderingIdentifier, "\" is not in the Coveo JSS Models mapping. Here are the available IDs: ", string.Join(", ", this.m_Renderings.Keys)));
                }
                return this.m_Renderings[renderingIdentifier];
            }
            else
            {
                return null;
            }
        }

        private RenderingSubModelDefinition ParseSubModel(string parentIdentifierProperty, string parentIdentifier, XmlNode node)
        {
            string attribute = XmlUtil.GetAttribute(CoveoJssRenderings.Attributes.SubModelName, node, true);
            Type type = this.CreateAndValidateType(parentIdentifierProperty, parentIdentifier, XmlUtil.GetAttribute(CoveoJssRenderings.Attributes.ModelType, node, true));
            return new RenderingSubModelDefinition()
            {
                Name = attribute,
                ModelType = type
            };
        }

        private static class Attributes
        {
            public static string Name;

            public static string ID;

            public static string ModelType;

            public static string ExcludedFields;

            public static string SubModel;

            public static string SubModelName;

            static Attributes()
            {
                CoveoJssRenderings.Attributes.Name = "name";
                CoveoJssRenderings.Attributes.ID = "id";
                CoveoJssRenderings.Attributes.ModelType = "modelType";
                CoveoJssRenderings.Attributes.ExcludedFields = "excludedFields";
                CoveoJssRenderings.Attributes.SubModel = "subModel";
                CoveoJssRenderings.Attributes.SubModelName = "name";
            }
        }
    }
}