﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace iData.Feature.CoveoHeadless.Coveo.Jss
{
    public class RenderingSubModelDefinition
    {
        public Type ModelType
        {
            get;
            set;
        }

        public string Name
        {
            get;
            set;
        }

        public RenderingSubModelDefinition()
        {
        }

        public void Deconstruct(out string name, out Type modelType)
        {
            name = this.Name;
            modelType = this.ModelType;
        }
    }
}