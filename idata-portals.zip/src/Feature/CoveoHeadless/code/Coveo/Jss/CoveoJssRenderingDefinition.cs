﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace iData.Feature.CoveoHeadless.Coveo.Jss
{
    public class CoveoJssRenderingDefinition
    {
        public string[] ExcludedFields
        {
            get;
            set;
        }

        public Type ModelType
        {
            get;
            set;
        }

        public RenderingSubModelDefinition[] SubModels
        {
            get;
            set;
        }

        public CoveoJssRenderingDefinition()
        {
        }

        public void Deconstruct(out Type modelType, out string[] excludedFields, out RenderingSubModelDefinition[] subModels)
        {
            modelType = this.ModelType;
            excludedFields = this.ExcludedFields;
            subModels = this.SubModels;
        }
    }
}