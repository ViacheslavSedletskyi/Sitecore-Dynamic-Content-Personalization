﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace iData.Feature.Navigation.Breadcrumb.Models
{
	public class BreadcrumbNavigation
	{
		public List<BreadcrumbModel> BreadCrumbs { get; set; }

		public BreadcrumbNavigation()
		{
		}
	}
}