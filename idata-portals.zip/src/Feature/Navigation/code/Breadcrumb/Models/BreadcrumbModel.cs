﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace iData.Feature.Navigation.Breadcrumb.Models
{
	public class BreadcrumbModel
	{
		public string Path { get; set; }

		public string Name { get; set; }
	}
}