﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using GraphQL;
using GraphQL.Resolvers;
using GraphQL.Types;
using Sitecore.Services.GraphQL.Schemas;
using Sitecore;
using Sitecore.Data.Items;
using Sitecore.Data;

namespace iData.Feature.Navigation.Breadcrumb.Models
{
	public class NavigationGraphType : ObjectGraphType<BreadcrumbNavigation>
	{
		public NavigationGraphType()
		{
			Name = "NavigationGraphType";

			Field<ListGraphType<BreadcrumbGraphType>>("breadcrumbs", null, null, x => x.Source.BreadCrumbs);
		}
	}
}