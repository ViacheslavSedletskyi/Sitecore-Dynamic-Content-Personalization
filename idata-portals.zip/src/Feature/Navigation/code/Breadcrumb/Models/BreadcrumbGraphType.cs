﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using GraphQL;
using GraphQL.Resolvers;
using GraphQL.Types;
using Sitecore.Services.GraphQL.Schemas;
using Sitecore;
using Sitecore.Data.Items;
using Sitecore.Data;

namespace iData.Feature.Navigation.Breadcrumb.Models
{
	public class BreadcrumbGraphType : ObjectGraphType<BreadcrumbModel>
	{
		public BreadcrumbGraphType()
		{
			Name = "BreadcrumbGraphType";

			Field<StringGraphType>("name", null, null, x => x.Source.Name);
			Field<StringGraphType>("path", null, null, x => x.Source.Path);
		}
	}
}