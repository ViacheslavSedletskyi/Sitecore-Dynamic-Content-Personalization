﻿
namespace iData.Feature.Navigation.Breadcrumb.Constant
{
    public struct Constant
    {
        public struct ArgumentKey
        {
            public const string ShowOnBreadcrumb = "showOnBreadcrumb";
            public const string BreadcrumbTitle = "breadcrumbTitle";
        }
    }
}