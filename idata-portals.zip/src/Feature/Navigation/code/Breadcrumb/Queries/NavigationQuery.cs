﻿using System.Collections.Generic;
using GraphQL.Types;
using Sitecore.Services.GraphQL.Schemas;
using Sitecore.Data.Items;
using Sitecore.Data;
using iData.Feature.Navigation.Breadcrumb.Models;
using Sitecore.Links;
using Sitecore.Services.GraphQL.Content;
using iData.Foundation.Platform;
using SC = Sitecore.Context;
using Sitecore.Diagnostics;
using System;

namespace iData.Feature.Navigation.Breadcrumb.Queries
{
	public class NavigationQuery : RootFieldType<NavigationGraphType, BreadcrumbNavigation>, IContentSchemaRootFieldType
	{
		public NavigationQuery() : base("allpath", "BreadcrumbNavigation query")
		{
			var queryArguments = new QueryArguments();

			var itemId = new QueryArgument<StringGraphType>
			{
				Name = "itemId",
				Description = "Item's Id to search under"
			};

			queryArguments.Add(itemId);

			Arguments = queryArguments;
		}

		public Database Database { get; set; }
		protected override BreadcrumbNavigation Resolve(ResolveFieldContext context)
		{
			var itemId = context.GetArgument("itemId", (string)null);

			var breadCrumbs = new List<BreadcrumbModel>();

			var result = new BreadcrumbNavigation();

			this.GetBreadcrumbItems(Database?.GetItem(itemId), breadCrumbs);

			breadCrumbs.Reverse();

			result.BreadCrumbs = breadCrumbs;

			return result;
		}
		

		public List<BreadcrumbModel> GetBreadcrumbItems(Item currentItem, List<BreadcrumbModel> resultList)
		{
			while (currentItem != null && !string.Equals(currentItem.TemplateID.ToString(), Foundation.Sitecore.Templates.Multisite._SiteRoot.ID.ToString() ))
			{
				if (currentItem[Constant.Constant.ArgumentKey.ShowOnBreadcrumb] == "1")
				{
					var breadcrumbName = string.Empty;
					
					if (currentItem.Name.Equals("*") && (SC.Items[Constants.SitecoreResolvedContextItemKey] is Item contextItem))
					{
						breadcrumbName = contextItem.Name;
					}
					else
					{
						var titleFieldValue = currentItem[Constant.Constant.ArgumentKey.BreadcrumbTitle];
						breadcrumbName = string.IsNullOrWhiteSpace(titleFieldValue) ? currentItem.Name : titleFieldValue;
					}

					resultList.Add(new BreadcrumbModel()
					{
						Name = breadcrumbName,
						Path = LinkManager.GetItemUrl(currentItem)
					});
				}

				if (currentItem.Parent == null)
				{
					var errorMessage = "Cannot construct breadcrumb - parent item of "
						+ currentItem.Paths.FullPath
						+ " is null. Please check sitecore tree and site root item template";

					Log.Error(errorMessage, this);

					throw new NullReferenceException(errorMessage);
				}

				currentItem = currentItem.Parent;
			}

			return resultList;
		}
    }
}