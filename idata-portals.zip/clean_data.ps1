# Clean data folders
Get-ChildItem -Path (Join-Path $PSScriptRoot "\docker\data") -Directory | ForEach-Object {
    $dataPath = $_.FullName

    Get-ChildItem -Path $dataPath -Exclude ".gitkeep","default.conf.template" -Recurse | Remove-Item -Force -Recurse -Verbose
}