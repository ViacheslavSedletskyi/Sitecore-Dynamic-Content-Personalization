    Write-Host "Pulling JSS deployed items..." -ForegroundColor Green

    dotnet sitecore ser pull